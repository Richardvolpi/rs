import java.io.IOException;

public class Map
{

    public void gjd(i k, int l, int i1, int j1, int k1, int l1)
    {
        gkk(i1, j1, 40);
        gkk(k1, l1, 40);
        int i2 = Ident.akf[l];
        int j2 = Ident.akg[l];
        int k2 = Ident.akh[l];
        int l2 = i1 * 128;
        int i3 = j1 * 128;
        int j3 = k1 * 128;
        int k3 = l1 * 128;
        int l3 = k.cln(l2, -gig[i1][j1], i3);
        int i4 = k.cln(l2, -gig[i1][j1] - i2, i3);
        int j4 = k.cln(j3, -gig[k1][l1] - i2, k3);
        int k4 = k.cln(j3, -gig[k1][l1], k3);
        int ai[] = {l3, i4, j4, k4};
        int l4 = k.cmb(4, ai, j2, k2);
        if(Ident.akj[l] == 5)
        {
            k.chl[l4] = 30000 + l;
            return;
        }
        else
        {
            k.chl[l4] = 0;
            return;
        }
    }

    public void gje(int arg0, int arg1, int arg2)
    {
        if(arg0 < 0 || arg0 >= 96 || arg1 < 0 || arg1 >= 96)
            return;
        byte byte0 = 0;
        if(arg0 >= 48 && arg1 < 48)
        {
            byte0 = 1;
            arg0 -= 48;
        }
        else if(arg0 < 48 && arg1 >= 48)
        {
            byte0 = 2;
            arg1 -= 48;
        }
        else if(arg0 >= 48 && arg1 >= 48)
        {
            byte0 = 3;
            arg0 -= 48;
            arg1 -= 48;
        }
        ghl[byte0][arg0 * 48 + arg1] = (byte)arg2;
    }

    public void gjf(int arg0, int arg1, int arg2, int arg3)
    {
        String s = "m" + arg2 + arg0 / 10 + arg0 % 10 + arg1 / 10 + arg1 % 10;
        int k;
        try
        {
            if(freeLand != null)
            {
                byte abyte0[] = Convert.Extract(s + ".hei", 0, freeLand);
                if(abyte0 == null && memberLand != null)
                    abyte0 = Convert.Extract(s + ".hei", 0, memberLand);
                if(abyte0 != null && abyte0.length > 0)
                {
                    int l = 0;
                    int i2 = 0;
                    for(int l2 = 0; l2 < 2304;)
                    {
                        int k3 = abyte0[l++] & 0xff;
                        if(k3 < 128)
                        {
                            gia[arg3][l2++] = (byte)k3;
                            i2 = k3;
                        }
                        if(k3 >= 128)
                        {
                            for(int k4 = 0; k4 < k3 - 128; k4++)
                                gia[arg3][l2++] = (byte)i2;
                        }
                    }
                    i2 = 64;
                    for(int l3 = 0; l3 < 48; l3++)
                    {
                        for(int l4 = 0; l4 < 48; l4++)
                        {
                            i2 = gia[arg3][l4 * 48 + l3] + i2 & 0x7f;
                            gia[arg3][l4 * 48 + l3] = (byte)(i2 * 2);
                        }
                    }
                    i2 = 0;
                    for(int i5 = 0; i5 < 2304;)
                    {
                        int l5 = abyte0[l++] & 0xff;
                        if(l5 < 128)
                        {
                            gid[arg3][i5++] = (byte)l5;
                            i2 = l5;
                        }
                        if(l5 >= 128)
                        {
                            for(int i7 = 0; i7 < l5 - 128; i7++)
                                gid[arg3][i5++] = (byte)i2;
                        }
                    }
                    i2 = 35;
                    for(int i6 = 0; i6 < 48; i6++)
                    {
                        for(int j7 = 0; j7 < 48; j7++)
                        {
                            i2 = gid[arg3][j7 * 48 + i6] + i2 & 0x7f;
                            gid[arg3][j7 * 48 + i6] = (byte)(i2 * 2);
                        }
                    }
                }
                else
                {
                    for(int i1 = 0; i1 < 2304; i1++)
                    {
                        gia[arg3][i1] = 0;
                        gid[arg3][i1] = 0;
                    }

                }
                abyte0 = Convert.Extract(s + ".dat", 0, freeMaps);
                if(abyte0 == null && memberMaps != null)
                    abyte0 = Convert.Extract(s + ".dat", 0, memberMaps);
                if(abyte0 == null || abyte0.length == 0)
                    throw new IOException();
                int j1 = 0;
                for(int j2 = 0; j2 < 2304; j2++)
                    ghg[arg3][j2] = abyte0[j1++];
                for(int i3 = 0; i3 < 2304; i3++)
                    gif[arg3][i3] = abyte0[j1++];
                for(int i4 = 0; i4 < 2304; i4++)
                    ghk[arg3][i4] = abyte0[j1++] & 0xff;
                for(int j5 = 0; j5 < 2304; j5++)
                {
                    int j6 = abyte0[j1++] & 0xff;
                    if(j6 > 0)
                        ghk[arg3][j5] = j6 + 12000;
                }
                for(int k6 = 0; k6 < 2304;)
                {
                    int k7 = abyte0[j1++] & 0xff;
                    if(k7 < 128)
                        gik[arg3][k6++] = (byte)k7;
                    else
                        for(int j8 = 0; j8 < k7 - 128; j8++)
                            gik[arg3][k6++] = 0;
                }
                int l7 = 0;
                for(int k8 = 0; k8 < 2304;)
                {
                    int i9 = abyte0[j1++] & 0xff;
                    if(i9 < 128)
                    {
                        ghl[arg3][k8++] = (byte)i9;
                        l7 = i9;
                    }
                    else
                        for(int l9 = 0; l9 < i9 - 128; l9++)
                            ghl[arg3][k8++] = (byte)l7;
                }
                for(int j9 = 0; j9 < 2304;)
                {
                    int i10 = abyte0[j1++] & 0xff;
                    if(i10 < 128)
                        ghn[arg3][j9++] = (byte)i10;
                    else
                        for(int l10 = 0; l10 < i10 - 128; l10++)
                            ghn[arg3][j9++] = 0;
                }
                abyte0 = Convert.Extract(s + ".loc", 0, freeMaps);
                if(abyte0 != null && abyte0.length > 0)
                {
                    int k1 = 0;
                    for(int j10 = 0; j10 < 2304;)
                    {
                        int i11 = abyte0[k1++] & 0xff;
                        if(i11 < 128)
                            ghk[arg3][j10++] = i11 + 48000;
                        else
                            j10 += i11 - 128;
                    }
                    return;
                }
            }
            return;
        }
        catch(IOException _ex)
        {
            k = 0;
        }
        for(; k < 2304; k++)
        {
            gia[arg3][k] = 0;
            gid[arg3][k] = 0;
            ghg[arg3][k] = 0;
            gif[arg3][k] = 0;
            ghk[arg3][k] = 0;
            gik[arg3][k] = 0;
            ghl[arg3][k] = 0;
            if(arg2 == 0)
                ghl[arg3][k] = -6;
            if(arg2 == 3)
                ghl[arg3][k] = 8;
            ghn[arg3][k] = 0;
        }
    }

    public int gjg(int arg0, int arg1)
    {
        if(arg0 < 0 || arg0 >= 96 || arg1 < 0 || arg1 >= 96)
            return 0;
        byte byte0 = 0;
        if(arg0 >= 48 && arg1 < 48)
        {
            byte0 = 1;
            arg0 -= 48;
        }
        else if(arg0 < 48 && arg1 >= 48)
        {
            byte0 = 2;
            arg1 -= 48;
        }
        else if(arg0 >= 48 && arg1 >= 48)
        {
            byte0 = 3;
            arg0 -= 48;
            arg1 -= 48;
        }
        return gid[byte0][arg0 * 48 + arg1] & 0xff;
    }

    public int gjh(int arg0, int arg1)
    {
        if(arg0 < 0 || arg0 >= 96 || arg1 < 0 || arg1 >= 96)
            return 0;
        byte byte0 = 0;
        if(arg0 >= 48 && arg1 < 48)
        {
            byte0 = 1;
            arg0 -= 48;
        }
        else if(arg0 < 48 && arg1 >= 48)
        {
            byte0 = 2;
            arg1 -= 48;
        }
        else if(arg0 >= 48 && arg1 >= 48)
        {
            byte0 = 3;
            arg0 -= 48;
            arg1 -= 48;
        }
        return ghn[byte0][arg0 * 48 + arg1];
    }

    public boolean gji(int k, int l)
    {
        return gkc(k, l) > 0 || gkc(k - 1, l) > 0 || gkc(k - 1, l - 1) > 0 || gkc(k, l - 1) > 0;
    }

    public void addObject(int arg0, int arg1, int arg2)
    {
        if(arg0 < 0 || arg1 < 0 || arg0 >= 95 || arg1 >= 95)
            return;
        if(Ident.aln[arg2] == 1 || Ident.aln[arg2] == 2)
        {
            int k = gjh(arg0, arg1);
            int l;
            int i1;
            if(k == 0 || k == 4)
            {
                l = Ident.all[arg2];
                i1 = Ident.alm[arg2];
            }
            else
            {
                i1 = Ident.all[arg2];
                l = Ident.alm[arg2];
            }
            for(int j1 = arg0; j1 < arg0 + l; j1++)
            {
                for(int k1 = arg1; k1 < arg1 + i1; k1++)
                    if(Ident.aln[arg2] == 1)
                        ghb[j1][k1] |= 0x40;
                    else if(k == 0)
                    {
                        ghb[j1][k1] |= 2;
                        if(j1 > 0)
                            gli(j1 - 1, k1, 8);
                    }
                    else if(k == 2)
                    {
                        ghb[j1][k1] |= 4;
                        if(k1 < 95)
                            gli(j1, k1 + 1, 1);
                    }
                    else if(k == 4)
                    {
                        ghb[j1][k1] |= 8;
                        if(j1 < 95)
                            gli(j1 + 1, k1, 2);
                    }
                    else if(k == 6)
                    {
                        ghb[j1][k1] |= 1;
                        if(k1 > 0)
                            gli(j1, k1 - 1, 4);
                    }
            }
            glc(arg0, arg1, l, i1);
        }
    }

    public int gjk(int arg0, int arg1, int arg2)
    {
        if(arg0 < 0 || arg0 >= 96 || arg1 < 0 || arg1 >= 96)
            return 0;
        byte byte0 = 0;
        if(arg0 >= 48 && arg1 < 48)
        {
            byte0 = 1;
            arg0 -= 48;
        }
        else if(arg0 < 48 && arg1 >= 48)
        {
            byte0 = 2;
            arg1 -= 48;
        }
        else if(arg0 >= 48 && arg1 >= 48)
        {
            byte0 = 3;
            arg0 -= 48;
            arg1 -= 48;
        }
        return ghl[byte0][arg0 * 48 + arg1] & 0xff;
    }

    public int gjl(int k, int l)
    {
        if(k < 0 || l < 0 || k >= 96 || l >= 96)
            return 0;
        else
            return ghb[k][l];
    }

    public int gjm(int k, int l, int i1, int j1)
    {
        int k1 = gjk(k, l, i1);
        if(k1 == 0)
            return j1;
        else
            return Ident.ahd[k1 - 1];
    }

    public void gka(int k, int l, int i1)
    {
        ghb[k][l] &= 65535 - i1;
    }

    public int countWayPoints(int arg0, int arg1, int arg2, int arg3, int arg4, int arg5, int xPath[], int yPath[], boolean arg8) // BOLLOCKS
    {
        if(arg0 < 0 || arg0 >= 96 || arg1 < 0 || arg1 >= 96)
            return -1;
        for(int k = 0; k < 96; k++)
            for(int l = 0; l < 96; l++)
                ghh[k][l] = 0;
        int i1 = 0;
        int j1 = 0;
        int k1 = arg0;
        int l1 = arg1;
        ghh[arg0][arg1] = 99;
        xPath[i1] = arg0;
        yPath[i1++] = arg1;
        int i2 = xPath.length;
        boolean flag = false;
        while(j1 != i1) 
        {
            k1 = xPath[j1];
            l1 = yPath[j1];
            j1 = (j1 + 1) % i2;
            if(k1 >= arg2 && k1 <= arg4 && l1 >= arg3 && l1 <= arg5)
            {
                flag = true;
                break;
            }
            if(arg8)
            {
                if(k1 > 0 && k1 - 1 >= arg2 && k1 - 1 <= arg4 && l1 >= arg3 && l1 <= arg5 && (ghb[k1 - 1][l1] & 8) == 0)
                {
                    flag = true;
                    break;
                }
                if(k1 < 95 && k1 + 1 >= arg2 && k1 + 1 <= arg4 && l1 >= arg3 && l1 <= arg5 && (ghb[k1 + 1][l1] & 2) == 0)
                {
                    flag = true;
                    break;
                }
                if(l1 > 0 && k1 >= arg2 && k1 <= arg4 && l1 - 1 >= arg3 && l1 - 1 <= arg5 && (ghb[k1][l1 - 1] & 4) == 0)
                {
                    flag = true;
                    break;
                }
                if(l1 < 95 && k1 >= arg2 && k1 <= arg4 && l1 + 1 >= arg3 && l1 + 1 <= arg5 && (ghb[k1][l1 + 1] & 1) == 0)
                {
                    flag = true;
                    break;
                }
            }
            if(k1 > 0 && ghh[k1 - 1][l1] == 0 && (ghb[k1 - 1][l1] & 0x78) == 0)
            {
                xPath[i1] = k1 - 1;
                yPath[i1] = l1;
                i1 = (i1 + 1) % i2;
                ghh[k1 - 1][l1] = 2;
            }
            if(k1 < 95 && ghh[k1 + 1][l1] == 0 && (ghb[k1 + 1][l1] & 0x72) == 0)
            {
                xPath[i1] = k1 + 1;
                yPath[i1] = l1;
                i1 = (i1 + 1) % i2;
                ghh[k1 + 1][l1] = 8;
            }
            if(l1 > 0 && ghh[k1][l1 - 1] == 0 && (ghb[k1][l1 - 1] & 0x74) == 0)
            {
                xPath[i1] = k1;
                yPath[i1] = l1 - 1;
                i1 = (i1 + 1) % i2;
                ghh[k1][l1 - 1] = 1;
            }
            if(l1 < 95 && ghh[k1][l1 + 1] == 0 && (ghb[k1][l1 + 1] & 0x71) == 0)
            {
                xPath[i1] = k1;
                yPath[i1] = l1 + 1;
                i1 = (i1 + 1) % i2;
                ghh[k1][l1 + 1] = 4;
            }
            if(k1 > 0 && l1 > 0 && (ghb[k1][l1 - 1] & 0x74) == 0 && (ghb[k1 - 1][l1] & 0x78) == 0 && (ghb[k1 - 1][l1 - 1] & 0x7c) == 0 && ghh[k1 - 1][l1 - 1] == 0)
            {
                xPath[i1] = k1 - 1;
                yPath[i1] = l1 - 1;
                i1 = (i1 + 1) % i2;
                ghh[k1 - 1][l1 - 1] = 3;
            }
            if(k1 < 95 && l1 > 0 && (ghb[k1][l1 - 1] & 0x74) == 0 && (ghb[k1 + 1][l1] & 0x72) == 0 && (ghb[k1 + 1][l1 - 1] & 0x76) == 0 && ghh[k1 + 1][l1 - 1] == 0)
            {
                xPath[i1] = k1 + 1;
                yPath[i1] = l1 - 1;
                i1 = (i1 + 1) % i2;
                ghh[k1 + 1][l1 - 1] = 9;
            }
            if(k1 > 0 && l1 < 95 && (ghb[k1][l1 + 1] & 0x71) == 0 && (ghb[k1 - 1][l1] & 0x78) == 0 && (ghb[k1 - 1][l1 + 1] & 0x79) == 0 && ghh[k1 - 1][l1 + 1] == 0)
            {
                xPath[i1] = k1 - 1;
                yPath[i1] = l1 + 1;
                i1 = (i1 + 1) % i2;
                ghh[k1 - 1][l1 + 1] = 6;
            }
            if(k1 < 95 && l1 < 95 && (ghb[k1][l1 + 1] & 0x71) == 0 && (ghb[k1 + 1][l1] & 0x72) == 0 && (ghb[k1 + 1][l1 + 1] & 0x73) == 0 && ghh[k1 + 1][l1 + 1] == 0)
            {
                xPath[i1] = k1 + 1;
                yPath[i1] = l1 + 1;
                i1 = (i1 + 1) % i2;
                ghh[k1 + 1][l1 + 1] = 12;
            }
        }
        if(!flag)
            return -1;
        j1 = 0;
        xPath[j1] = k1;
        yPath[j1++] = l1;
        int k2;
        for(int j2 = k2 = ghh[k1][l1]; k1 != arg0 || l1 != arg1; j2 = ghh[k1][l1])
        {
            if(j2 != k2)
            {
                k2 = j2;
                xPath[j1] = k1;
                yPath[j1++] = l1;
            }
            if((j2 & 2) != 0)
                k1++;
            else if((j2 & 8) != 0)
                k1--;
            if((j2 & 1) != 0)
                l1++;
            else if((j2 & 4) != 0)
                l1--;
        }
        return j1;
    }

    public int gkc(int arg0, int arg1)
    {
        if(arg0 < 0 || arg0 >= 96 || arg1 < 0 || arg1 >= 96)
            return 0;
        byte byte0 = 0;
        if(arg0 >= 48 && arg1 < 48)
        {
            byte0 = 1;
            arg0 -= 48;
        }
        else if(arg0 < 48 && arg1 >= 48)
        {
            byte0 = 2;
            arg1 -= 48;
        }
        else if(arg0 >= 48 && arg1 >= 48)
        {
            byte0 = 3;
            arg0 -= 48;
            arg1 -= 48;
        }
        return gik[byte0][arg0 * 48 + arg1];
    }

    public int gkd(int arg0, int arg1)
    {
        if(arg0 < 0 || arg0 >= 96 || arg1 < 0 || arg1 >= 96)
            return 0;
        byte byte0 = 0;
        if(arg0 >= 48 && arg1 < 48)
        {
            byte0 = 1;
            arg0 -= 48;
        }
        else if(arg0 < 48 && arg1 >= 48)
        {
            byte0 = 2;
            arg1 -= 48;
        }
        else if(arg0 >= 48 && arg1 >= 48)
        {
            byte0 = 3;
            arg0 -= 48;
            arg1 -= 48;
        }
        return (gia[byte0][arg0 * 48 + arg1] & 0xff) * 3;
    }

    public void addWallObject1(int arg0, int arg1, int arg2, int arg3)
    {
        if(arg0 < 0 || arg1 < 0 || arg0 >= 95 || arg1 >= 95)
            return;
        if(Ident.aki[arg3] == 1)
        {
            if(arg2 == 0)
            {
                ghb[arg0][arg1] &= 0xfffe;
                if(arg1 > 0)
                    gka(arg0, arg1 - 1, 4);
            }
            else if(arg2 == 1)
            {
                ghb[arg0][arg1] &= 0xfffd;
                if(arg0 > 0)
                    gka(arg0 - 1, arg1, 8);
            }
            else if(arg2 == 2)
                ghb[arg0][arg1] &= 0xffef;
            else if(arg2 == 3)
                ghb[arg0][arg1] &= 0xffdf;
            glc(arg0, arg1, 1, 1);
        }
    }

    public void loadTile(int k, int l, int i1)
    {
        gkh();
        int j1 = (k + 24) / 48;
        int k1 = (l + 24) / 48;
        gkm(k, l, i1, true);
        if(i1 == 0)
        {
            gkm(k, l, 1, false);
            gkm(k, l, 2, false);
            gjf(j1 - 1, k1 - 1, i1, 0);
            gjf(j1, k1 - 1, i1, 1);
            gjf(j1 - 1, k1, i1, 2);
            gjf(j1, k1, i1, 3);
            glb();
        }
    }

    public void addObject1(int arg0, int arg1, int arg2)
    {
        if(arg0 < 0 || arg1 < 0 || arg0 >= 95 || arg1 >= 95)
            return;
        if(Ident.aln[arg2] == 1 || Ident.aln[arg2] == 2)
        {
            int k = gjh(arg0, arg1);
            int l;
            int i1;
            if(k == 0 || k == 4)
            {
                l = Ident.all[arg2];
                i1 = Ident.alm[arg2];
            }
            else
            {
                i1 = Ident.all[arg2];
                l = Ident.alm[arg2];
            }
            for(int j1 = arg0; j1 < arg0 + l; j1++)
            {
                for(int k1 = arg1; k1 < arg1 + i1; k1++)
                    if(Ident.aln[arg2] == 1)
                        ghb[j1][k1] &= 0xffbf;
                    else if(k == 0)
                    {
                        ghb[j1][k1] &= 0xfffd;
                        if(j1 > 0)
                            gka(j1 - 1, k1, 8);
                    }
                    else if(k == 2)
                    {
                        ghb[j1][k1] &= 0xfffb;
                        if(k1 < 95)
                            gka(j1, k1 + 1, 1);
                    }
                    else if(k == 4)
                    {
                        ghb[j1][k1] &= 0xfff7;
                        if(j1 < 95)
                            gka(j1 + 1, k1, 2);
                    }
                    else if(k == 6)
                    {
                        ghb[j1][k1] &= 0xfffe;
                        if(k1 > 0)
                            gka(j1, k1 - 1, 4);
                    }
            }
            glc(arg0, arg1, l, i1);
        }
    }

    public void gkh()
    {
        for(int k = 0; k < 64; k++)
        {
            gim[k] = null;
            for(int l = 0; l < 4; l++)
                ghm[l][k] = null;
            for(int i1 = 0; i1 < 4; i1++)
                gih[i1][k] = null;
        }
        System.gc();
    }

    public void gki(int arg0, int arg1, int arg2, int arg3, int arg4)
    {
        i k = gim[arg0 + arg1 * 8];
        for(int l = 0; l < k.cfh; l++)
            if(k.cil[l] == arg2 * 128 && k.cin[l] == arg3 * 128)
            {
                k.cmh(l, arg4);
                return;
            }
    }

    public void addWallObject(int arg0, int arg1, int arg2, int arg3)
    {
        if(arg0 < 0 || arg1 < 0 || arg0 >= 95 || arg1 >= 95)
            return;
        if(Ident.aki[arg3] == 1)
        {
            if(arg2 == 0)
            {
                ghb[arg0][arg1] |= 1;
                if(arg1 > 0)
                    gli(arg0, arg1 - 1, 4);
            }
            else if(arg2 == 1)
            {
                ghb[arg0][arg1] |= 2;
                if(arg0 > 0)
                    gli(arg0 - 1, arg1, 8);
            }
            else if(arg2 == 2)
                ghb[arg0][arg1] |= 0x10;
            else if(arg2 == 3)
                ghb[arg0][arg1] |= 0x20;
            glc(arg0, arg1, 1, 1);
        }
    }

    public void gkk(int k, int l, int i1)
    {
        int j1 = k / 12;
        int k1 = l / 12;
        int l1 = (k - 1) / 12;
        int i2 = (l - 1) / 12;
        gki(j1, k1, k, l, i1);
        if(j1 != l1)
            gki(l1, k1, k, l, i1);
        if(k1 != i2)
            gki(j1, i2, k, l, i1);
        if(j1 != l1 && k1 != i2)
            gki(l1, i2, k, l, i1);
    }

    public int gkl(int arg0, int arg1)
    {
        if(arg0 < 0 || arg0 >= 96 || arg1 < 0 || arg1 >= 96)
            return 0;
        byte byte0 = 0;
        if(arg0 >= 48 && arg1 < 48)
        {
            byte0 = 1;
            arg0 -= 48;
        }
        else if(arg0 < 48 && arg1 >= 48)
        {
            byte0 = 2;
            arg1 -= 48;
        }
        else if(arg0 >= 48 && arg1 >= 48)
        {
            byte0 = 3;
            arg0 -= 48;
            arg1 -= 48;
        }
        return gif[byte0][arg0 * 48 + arg1] & 0xff;
    }

    public void gkm(int arg0, int arg1, int arg2, boolean arg3)
    {
        int k = (arg0 + 24) / 48;
        int l = (arg1 + 24) / 48;
        gjf(k - 1, l - 1, arg2, 0);
        gjf(k, l - 1, arg2, 1);
        gjf(k - 1, l, arg2, 2);
        gjf(k, l, arg2, 3);
        glb();
        if(gin == null)
            gin = new i(18688, 18688, true, true, false, false, true);
        if(arg3)
        {
            for(int i1 = 0; i1 < 96; i1++)
                for(int k1 = 0; k1 < 96; k1++)
                    ghb[i1][k1] = 0;
            i l1 = gin;
            l1.clk();
            for(int j2 = 0; j2 < 96; j2++)
            {
                for(int i3 = 0; i3 < 96; i3++)
                {
                    int i4 = -gkd(j2, i3);
                    if(gjk(j2, i3, arg2) > 0 && Ident.ahe[gjk(j2, i3, arg2) - 1] == 4)
                        i4 = 0;
                    if(gjk(j2 - 1, i3, arg2) > 0 && Ident.ahe[gjk(j2 - 1, i3, arg2) - 1] == 4)
                        i4 = 0;
                    if(gjk(j2, i3 - 1, arg2) > 0 && Ident.ahe[gjk(j2, i3 - 1, arg2) - 1] == 4)
                        i4 = 0;
                    if(gjk(j2 - 1, i3 - 1, arg2) > 0 && Ident.ahe[gjk(j2 - 1, i3 - 1, arg2) - 1] == 4)
                        i4 = 0;
                    int j5 = l1.cln(j2 * 128, i4, i3 * 128);
                    int j7 = (int)(Math.random() * 10D) - 5;
                    l1.cmh(j5, j7);
                }
            }
            for(int j3 = 0; j3 < 95; j3++)
            {
                for(int j4 = 0; j4 < 95; j4++)
                {
                    int k5 = gjg(j3, j4);
                    int k7 = ghc[k5];
                    int i10 = k7;
                    int k12 = k7;
                    int l14 = 0;
                    if(arg2 == 1 || arg2 == 2)
                    {
                        k7 = 0xbc614e;
                        i10 = 0xbc614e;
                        k12 = 0xbc614e;
                    }
                    if(gjk(j3, j4, arg2) > 0)
                    {
                        int l16 = gjk(j3, j4, arg2);
                        int l5 = Ident.ahe[l16 - 1];
                        int i19 = glg(j3, j4, arg2);
                        k7 = i10 = Ident.ahd[l16 - 1];
                        if(l5 == 4)
                        {
                            k7 = 1;
                            i10 = 1;
                            if(l16 == 12)
                            {
                                k7 = 31;
                                i10 = 31;
                            }
                        }
                        if(l5 == 5)
                        {
                            if(gkn(j3, j4) > 0 && gkn(j3, j4) < 24000)
                                if(gjm(j3 - 1, j4, arg2, k12) != 0xbc614e && gjm(j3, j4 - 1, arg2, k12) != 0xbc614e)
                                {
                                    k7 = gjm(j3 - 1, j4, arg2, k12);
                                    l14 = 0;
                                }
                                else if(gjm(j3 + 1, j4, arg2, k12) != 0xbc614e && gjm(j3, j4 + 1, arg2, k12) != 0xbc614e)
                                {
                                    i10 = gjm(j3 + 1, j4, arg2, k12);
                                    l14 = 0;
                                }
                                else if(gjm(j3 + 1, j4, arg2, k12) != 0xbc614e && gjm(j3, j4 - 1, arg2, k12) != 0xbc614e)
                                {
                                    i10 = gjm(j3 + 1, j4, arg2, k12);
                                    l14 = 1;
                                }
                                else if(gjm(j3 - 1, j4, arg2, k12) != 0xbc614e && gjm(j3, j4 + 1, arg2, k12) != 0xbc614e)
                                {
                                    k7 = gjm(j3 - 1, j4, arg2, k12);
                                    l14 = 1;
                                }
                        }
                        else if(l5 != 2 || gkn(j3, j4) > 0 && gkn(j3, j4) < 24000)
                            if(glg(j3 - 1, j4, arg2) != i19 && glg(j3, j4 - 1, arg2) != i19)
                            {
                                k7 = k12;
                                l14 = 0;
                            }
                            else if(glg(j3 + 1, j4, arg2) != i19 && glg(j3, j4 + 1, arg2) != i19)
                            {
                                i10 = k12;
                                l14 = 0;
                            }
                            else if(glg(j3 + 1, j4, arg2) != i19 && glg(j3, j4 - 1, arg2) != i19)
                            {
                                i10 = k12;
                                l14 = 1;
                            }
                            else if(glg(j3 - 1, j4, arg2) != i19 && glg(j3, j4 + 1, arg2) != i19)
                            {
                                k7 = k12;
                                l14 = 1;
                            }
                        if(Ident.ahf[l16 - 1] != 0)
                            ghb[j3][j4] |= 0x40;
                        if(Ident.ahe[l16 - 1] == 2)
                            ghb[j3][j4] |= 0x80;
                    }
                    int i17 = ((gkd(j3 + 1, j4 + 1) - gkd(j3 + 1, j4)) + gkd(j3, j4 + 1)) - gkd(j3, j4);
                    if(k7 != i10 || i17 != 0)
                    {
                        int ai[] = new int[3];
                        int ai7[] = new int[3];
                        if(l14 == 0)
                        {
                            if(k7 != 0xbc614e)
                            {
                                ai[0] = j4 + j3 * 96 + 96;
                                ai[1] = j4 + j3 * 96;
                                ai[2] = j4 + j3 * 96 + 1;
                                int l21 = l1.cmb(3, ai, 0xbc614e, k7);
                                gjc[l21] = j3;
                                ghj[l21] = j4;
                                l1.chl[l21] = 0x30d40 + l21;
                            }
                            if(i10 != 0xbc614e)
                            {
                                ai7[0] = j4 + j3 * 96 + 1;
                                ai7[1] = j4 + j3 * 96 + 96 + 1;
                                ai7[2] = j4 + j3 * 96 + 96;
                                int i22 = l1.cmb(3, ai7, 0xbc614e, i10);
                                gjc[i22] = j3;
                                ghj[i22] = j4;
                                l1.chl[i22] = 0x30d40 + i22;
                            }
                        }
                        else
                        {
                            if(k7 != 0xbc614e)
                            {
                                ai[0] = j4 + j3 * 96 + 1;
                                ai[1] = j4 + j3 * 96 + 96 + 1;
                                ai[2] = j4 + j3 * 96;
                                int j22 = l1.cmb(3, ai, 0xbc614e, k7);
                                gjc[j22] = j3;
                                ghj[j22] = j4;
                                l1.chl[j22] = 0x30d40 + j22;
                            }
                            if(i10 != 0xbc614e)
                            {
                                ai7[0] = j4 + j3 * 96 + 96;
                                ai7[1] = j4 + j3 * 96;
                                ai7[2] = j4 + j3 * 96 + 96 + 1;
                                int k22 = l1.cmb(3, ai7, 0xbc614e, i10);
                                gjc[k22] = j3;
                                ghj[k22] = j4;
                                l1.chl[k22] = 0x30d40 + k22;
                            }
                        }
                    }
                    else if(k7 != 0xbc614e)
                    {
                        int ai1[] = new int[4];
                        ai1[0] = j4 + j3 * 96 + 96;
                        ai1[1] = j4 + j3 * 96;
                        ai1[2] = j4 + j3 * 96 + 1;
                        ai1[3] = j4 + j3 * 96 + 96 + 1;
                        int l19 = l1.cmb(4, ai1, 0xbc614e, k7);
                        gjc[l19] = j3;
                        ghj[l19] = j4;
                        l1.chl[l19] = 0x30d40 + l19;
                    }
                }
            }
            for(int k4 = 1; k4 < 95; k4++)
            {
                for(int i6 = 1; i6 < 95; i6++)
                    if(gjk(k4, i6, arg2) > 0 && Ident.ahe[gjk(k4, i6, arg2) - 1] == 4)
                    {
                        int l7 = Ident.ahd[gjk(k4, i6, arg2) - 1];
                        int j10 = l1.cln(k4 * 128, -gkd(k4, i6), i6 * 128);
                        int l12 = l1.cln((k4 + 1) * 128, -gkd(k4 + 1, i6), i6 * 128);
                        int i15 = l1.cln((k4 + 1) * 128, -gkd(k4 + 1, i6 + 1), (i6 + 1) * 128);
                        int j17 = l1.cln(k4 * 128, -gkd(k4, i6 + 1), (i6 + 1) * 128);
                        int ai2[] = {j10, l12, i15, j17};
                        int i20 = l1.cmb(4, ai2, l7, 0xbc614e);
                        gjc[i20] = k4;
                        ghj[i20] = i6;
                        l1.chl[i20] = 0x30d40 + i20;
                    }
                    else if(gjk(k4, i6, arg2) == 0 || Ident.ahe[gjk(k4, i6, arg2) - 1] != 3)
                    {
                        if(gjk(k4, i6 + 1, arg2) > 0 && Ident.ahe[gjk(k4, i6 + 1, arg2) - 1] == 4)
                        {
                            int i8 = Ident.ahd[gjk(k4, i6 + 1, arg2) - 1];
                            int k10 = l1.cln(k4 * 128, -gkd(k4, i6), i6 * 128);
                            int i13 = l1.cln((k4 + 1) * 128, -gkd(k4 + 1, i6), i6 * 128);
                            int j15 = l1.cln((k4 + 1) * 128, -gkd(k4 + 1, i6 + 1), (i6 + 1) * 128);
                            int k17 = l1.cln(k4 * 128, -gkd(k4, i6 + 1), (i6 + 1) * 128);
                            int ai3[] = {
                                k10, i13, j15, k17
                            };
                            int j20 = l1.cmb(4, ai3, i8, 0xbc614e);
                            gjc[j20] = k4;
                            ghj[j20] = i6;
                            l1.chl[j20] = 0x30d40 + j20;
                        }
                        if(gjk(k4, i6 - 1, arg2) > 0 && Ident.ahe[gjk(k4, i6 - 1, arg2) - 1] == 4)
                        {
                            int j8 = Ident.ahd[gjk(k4, i6 - 1, arg2) - 1];
                            int l10 = l1.cln(k4 * 128, -gkd(k4, i6), i6 * 128);
                            int j13 = l1.cln((k4 + 1) * 128, -gkd(k4 + 1, i6), i6 * 128);
                            int k15 = l1.cln((k4 + 1) * 128, -gkd(k4 + 1, i6 + 1), (i6 + 1) * 128);
                            int l17 = l1.cln(k4 * 128, -gkd(k4, i6 + 1), (i6 + 1) * 128);
                            int ai4[] = {
                                l10, j13, k15, l17
                            };
                            int k20 = l1.cmb(4, ai4, j8, 0xbc614e);
                            gjc[k20] = k4;
                            ghj[k20] = i6;
                            l1.chl[k20] = 0x30d40 + k20;
                        }
                        if(gjk(k4 + 1, i6, arg2) > 0 && Ident.ahe[gjk(k4 + 1, i6, arg2) - 1] == 4)
                        {
                            int k8 = Ident.ahd[gjk(k4 + 1, i6, arg2) - 1];
                            int i11 = l1.cln(k4 * 128, -gkd(k4, i6), i6 * 128);
                            int k13 = l1.cln((k4 + 1) * 128, -gkd(k4 + 1, i6), i6 * 128);
                            int l15 = l1.cln((k4 + 1) * 128, -gkd(k4 + 1, i6 + 1), (i6 + 1) * 128);
                            int i18 = l1.cln(k4 * 128, -gkd(k4, i6 + 1), (i6 + 1) * 128);
                            int ai5[] = {
                                i11, k13, l15, i18
                            };
                            int l20 = l1.cmb(4, ai5, k8, 0xbc614e);
                            gjc[l20] = k4;
                            ghj[l20] = i6;
                            l1.chl[l20] = 0x30d40 + l20;
                        }
                        if(gjk(k4 - 1, i6, arg2) > 0 && Ident.ahe[gjk(k4 - 1, i6, arg2) - 1] == 4)
                        {
                            int l8 = Ident.ahd[gjk(k4 - 1, i6, arg2) - 1];
                            int j11 = l1.cln(k4 * 128, -gkd(k4, i6), i6 * 128);
                            int l13 = l1.cln((k4 + 1) * 128, -gkd(k4 + 1, i6), i6 * 128);
                            int i16 = l1.cln((k4 + 1) * 128, -gkd(k4 + 1, i6 + 1), (i6 + 1) * 128);
                            int j18 = l1.cln(k4 * 128, -gkd(k4, i6 + 1), (i6 + 1) * 128);
                            int ai6[] = {
                                j11, l13, i16, j18
                            };
                            int i21 = l1.cmb(4, ai6, l8, 0xbc614e);
                            gjc[i21] = k4;
                            ghj[i21] = i6;
                            l1.chl[i21] = 0x30d40 + i21;
                        }
                    }
            }
            l1.cme(true, 40, 48, -50, -10, -50);
            gim = gin.cmc(0, 0, 1536, 1536, 8, 64, 233, false);
            for(int i9 = 0; i9 < 96; i9++)
            {
                for(int k11 = 0; k11 < 96; k11++)
                    gig[i9][k11] = gkd(i9, k11);
            }
        }
        gin.clk();
        int j1 = 0x606060;
        for(int i2 = 0; i2 < 95; i2++)
        {
            for(int k2 = 0; k2 < 95; k2++)
            {
                int k3 = gkl(i2, k2);
                if(k3 > 0 && (Ident.akj[k3 - 1] == 0 || ghf))
                {
                    gjd(gin, k3 - 1, i2, k2, i2 + 1, k2);
                    if(arg3 && Ident.aki[k3 - 1] != 0)
                    {
                        ghb[i2][k2] |= 1;
                        if(k2 > 0)
                            gli(i2, k2 - 1, 4);
                    }
                }
                k3 = glf(i2, k2);
                if(k3 > 0 && (Ident.akj[k3 - 1] == 0 || ghf))
                {
                    gjd(gin, k3 - 1, i2, k2, i2, k2 + 1);
                    if(arg3 && Ident.aki[k3 - 1] != 0)
                    {
                        ghb[i2][k2] |= 2;
                        if(i2 > 0)
                            gli(i2 - 1, k2, 8);
                    }
                }
                k3 = gkn(i2, k2);
                if(k3 > 0 && k3 < 12000 && (Ident.akj[k3 - 1] == 0 || ghf))
                {
                    gjd(gin, k3 - 1, i2, k2, i2 + 1, k2 + 1);
                    if(arg3 && Ident.aki[k3 - 1] != 0)
                        ghb[i2][k2] |= 0x20;
                }
                if(k3 > 12000 && k3 < 24000 && (Ident.akj[k3 - 12001] == 0 || ghf))
                {
                    gjd(gin, k3 - 12001, i2 + 1, k2, i2, k2 + 1);
                    if(arg3 && Ident.aki[k3 - 12001] != 0)
                        ghb[i2][k2] |= 0x10;
                }
            }
        }
        gin.cme(false, 60, 24, -50, -10, -50);
        ghm[arg2] = gin.cmc(0, 0, 1536, 1536, 8, 64, 338, true);
        for(int l3 = 0; l3 < 95; l3++)
        {
            for(int l4 = 0; l4 < 95; l4++)
            {
                int k6 = gkl(l3, l4);
                if(k6 > 0)
                    glh(k6 - 1, l3, l4, l3 + 1, l4);
                k6 = glf(l3, l4);
                if(k6 > 0)
                    glh(k6 - 1, l3, l4, l3, l4 + 1);
                k6 = gkn(l3, l4);
                if(k6 > 0 && k6 < 12000)
                    glh(k6 - 1, l3, l4, l3 + 1, l4 + 1);
                if(k6 > 12000 && k6 < 24000)
                    glh(k6 - 12001, l3 + 1, l4, l3, l4 + 1);
            }
        }
        for(int i5 = 1; i5 < 95; i5++)
        {
            for(int l6 = 1; l6 < 95; l6++)
            {
                int j9 = gkc(i5, l6);
                if(j9 > 0)
                {
                    int l11 = i5;
                    int i14 = l6;
                    int j16 = i5 + 1;
                    int k18 = l6;
                    int j19 = i5 + 1;
                    int j21 = l6 + 1;
                    int l22 = i5;
                    int j23 = l6 + 1;
                    int l23 = 0;
                    int j24 = gig[l11][i14];
                    int l24 = gig[j16][k18];
                    int j25 = gig[j19][j21];
                    int l25 = gig[l22][j23];
                    if(j24 > 0x13880)
                        j24 -= 0x13880;
                    if(l24 > 0x13880)
                        l24 -= 0x13880;
                    if(j25 > 0x13880)
                        j25 -= 0x13880;
                    if(l25 > 0x13880)
                        l25 -= 0x13880;
                    if(j24 > l23)
                        l23 = j24;
                    if(l24 > l23)
                        l23 = l24;
                    if(j25 > l23)
                        l23 = j25;
                    if(l25 > l23)
                        l23 = l25;
                    if(l23 >= 0x13880)
                        l23 -= 0x13880;
                    if(j24 < 0x13880)
                        gig[l11][i14] = l23;
                    else
                        gig[l11][i14] -= 0x13880;
                    if(l24 < 0x13880)
                        gig[j16][k18] = l23;
                    else
                        gig[j16][k18] -= 0x13880;
                    if(j25 < 0x13880)
                        gig[j19][j21] = l23;
                    else
                        gig[j19][j21] -= 0x13880;
                    if(l25 < 0x13880)
                        gig[l22][j23] = l23;
                    else
                        gig[l22][j23] -= 0x13880;
                }
            }
        }
        gin.clk();
        for(int i7 = 1; i7 < 95; i7++)
        {
            for(int k9 = 1; k9 < 95; k9++)
            {
                int i12 = gkc(i7, k9);
                if(i12 > 0)
                {
                    int j14 = i7;
                    int k16 = k9;
                    int l18 = i7 + 1;
                    int k19 = k9;
                    int k21 = i7 + 1;
                    int i23 = k9 + 1;
                    int k23 = i7;
                    int i24 = k9 + 1;
                    int k24 = i7 * 128;
                    int i25 = k9 * 128;
                    int k25 = k24 + 128;
                    int i26 = i25 + 128;
                    int j26 = k24;
                    int k26 = i25;
                    int l26 = k25;
                    int i27 = i26;
                    int j27 = gig[j14][k16];
                    int k27 = gig[l18][k19];
                    int l27 = gig[k21][i23];
                    int i28 = gig[k23][i24];
                    int j28 = Ident.ali[i12 - 1];
                    if(gld(j14, k16) && j27 < 0x13880)
                    {
                        j27 += j28 + 0x13880;
                        gig[j14][k16] = j27;
                    }
                    if(gld(l18, k19) && k27 < 0x13880)
                    {
                        k27 += j28 + 0x13880;
                        gig[l18][k19] = k27;
                    }
                    if(gld(k21, i23) && l27 < 0x13880)
                    {
                        l27 += j28 + 0x13880;
                        gig[k21][i23] = l27;
                    }
                    if(gld(k23, i24) && i28 < 0x13880)
                    {
                        i28 += j28 + 0x13880;
                        gig[k23][i24] = i28;
                    }
                    if(j27 >= 0x13880)
                        j27 -= 0x13880;
                    if(k27 >= 0x13880)
                        k27 -= 0x13880;
                    if(l27 >= 0x13880)
                        l27 -= 0x13880;
                    if(i28 >= 0x13880)
                        i28 -= 0x13880;
                    byte byte0 = 16;
                    if(!gji(j14 - 1, k16))
                        k24 -= byte0;
                    if(!gji(j14 + 1, k16))
                        k24 += byte0;
                    if(!gji(j14, k16 - 1))
                        i25 -= byte0;
                    if(!gji(j14, k16 + 1))
                        i25 += byte0;
                    if(!gji(l18 - 1, k19))
                        k25 -= byte0;
                    if(!gji(l18 + 1, k19))
                        k25 += byte0;
                    if(!gji(l18, k19 - 1))
                        k26 -= byte0;
                    if(!gji(l18, k19 + 1))
                        k26 += byte0;
                    if(!gji(k21 - 1, i23))
                        l26 -= byte0;
                    if(!gji(k21 + 1, i23))
                        l26 += byte0;
                    if(!gji(k21, i23 - 1))
                        i26 -= byte0;
                    if(!gji(k21, i23 + 1))
                        i26 += byte0;
                    if(!gji(k23 - 1, i24))
                        j26 -= byte0;
                    if(!gji(k23 + 1, i24))
                        j26 += byte0;
                    if(!gji(k23, i24 - 1))
                        i27 -= byte0;
                    if(!gji(k23, i24 + 1))
                        i27 += byte0;
                    i12 = Ident.alj[i12 - 1];
                    j27 = -j27;
                    k27 = -k27;
                    l27 = -l27;
                    i28 = -i28;
                    if(gkn(i7, k9) > 12000 && gkn(i7, k9) < 24000 && gkc(i7 - 1, k9 - 1) == 0)
                    {
                        int ai8[] = new int[3];
                        ai8[0] = gin.cln(l26, l27, i26);
                        ai8[1] = gin.cln(j26, i28, i27);
                        ai8[2] = gin.cln(k25, k27, k26);
                        gin.cmb(3, ai8, i12, 0xbc614e);
                    }
                    else if(gkn(i7, k9) > 12000 && gkn(i7, k9) < 24000 && gkc(i7 + 1, k9 + 1) == 0)
                    {
                        int ai9[] = new int[3];
                        ai9[0] = gin.cln(k24, j27, i25);
                        ai9[1] = gin.cln(k25, k27, k26);
                        ai9[2] = gin.cln(j26, i28, i27);
                        gin.cmb(3, ai9, i12, 0xbc614e);
                    }
                    else if(gkn(i7, k9) > 0 && gkn(i7, k9) < 12000 && gkc(i7 + 1, k9 - 1) == 0)
                    {
                        int ai10[] = new int[3];
                        ai10[0] = gin.cln(j26, i28, i27);
                        ai10[1] = gin.cln(k24, j27, i25);
                        ai10[2] = gin.cln(l26, l27, i26);
                        gin.cmb(3, ai10, i12, 0xbc614e);
                    }
                    else if(gkn(i7, k9) > 0 && gkn(i7, k9) < 12000 && gkc(i7 - 1, k9 + 1) == 0)
                    {
                        int ai11[] = new int[3];
                        ai11[0] = gin.cln(k25, k27, k26);
                        ai11[1] = gin.cln(l26, l27, i26);
                        ai11[2] = gin.cln(k24, j27, i25);
                        gin.cmb(3, ai11, i12, 0xbc614e);
                    }
                    else if(j27 == k27 && l27 == i28)
                    {
                        int ai12[] = new int[4];
                        ai12[0] = gin.cln(k24, j27, i25);
                        ai12[1] = gin.cln(k25, k27, k26);
                        ai12[2] = gin.cln(l26, l27, i26);
                        ai12[3] = gin.cln(j26, i28, i27);
                        gin.cmb(4, ai12, i12, 0xbc614e);
                    }
                    else if(j27 == i28 && k27 == l27)
                    {
                        int ai13[] = new int[4];
                        ai13[0] = gin.cln(j26, i28, i27);
                        ai13[1] = gin.cln(k24, j27, i25);
                        ai13[2] = gin.cln(k25, k27, k26);
                        ai13[3] = gin.cln(l26, l27, i26);
                        gin.cmb(4, ai13, i12, 0xbc614e);
                    }
                    else
                    {
                        boolean flag = true;
                        if(gkc(i7 - 1, k9 - 1) > 0)
                            flag = false;
                        if(gkc(i7 + 1, k9 + 1) > 0)
                            flag = false;
                        if(!flag)
                        {
                            int ai14[] = new int[3];
                            ai14[0] = gin.cln(k25, k27, k26);
                            ai14[1] = gin.cln(l26, l27, i26);
                            ai14[2] = gin.cln(k24, j27, i25);
                            gin.cmb(3, ai14, i12, 0xbc614e);
                            int ai16[] = new int[3];
                            ai16[0] = gin.cln(j26, i28, i27);
                            ai16[1] = gin.cln(k24, j27, i25);
                            ai16[2] = gin.cln(l26, l27, i26);
                            gin.cmb(3, ai16, i12, 0xbc614e);
                        }
                        else
                        {
                            int ai15[] = new int[3];
                            ai15[0] = gin.cln(k24, j27, i25);
                            ai15[1] = gin.cln(k25, k27, k26);
                            ai15[2] = gin.cln(j26, i28, i27);
                            gin.cmb(3, ai15, i12, 0xbc614e);
                            int ai17[] = new int[3];
                            ai17[0] = gin.cln(l26, l27, i26);
                            ai17[1] = gin.cln(j26, i28, i27);
                            ai17[2] = gin.cln(k25, k27, k26);
                            gin.cmb(3, ai17, i12, 0xbc614e);
                        }
                    }
                }
            }
        }
        gin.cme(true, 50, 50, -50, -10, -50);
        gih[arg2] = gin.cmc(0, 0, 1536, 1536, 8, 64, 169, true);
        if(gih[arg2][0] == null)
            throw new RuntimeException("null roof!");
        for(int j12 = 0; j12 < 96; j12++)
        {
            for(int k14 = 0; k14 < 96; k14++)
                if(gig[j12][k14] >= 0x13880)
                    gig[j12][k14] -= 0x13880;
        }
    }

    public int gkn(int arg0, int arg1)
    {
        if(arg0 < 0 || arg0 >= 96 || arg1 < 0 || arg1 >= 96)
            return 0;
        byte byte0 = 0;
        if(arg0 >= 48 && arg1 < 48)
        {
            byte0 = 1;
            arg0 -= 48;
        }
        else if(arg0 < 48 && arg1 >= 48)
        {
            byte0 = 2;
            arg1 -= 48;
        }
        else if(arg0 >= 48 && arg1 >= 48)
        {
            byte0 = 3;
            arg0 -= 48;
            arg1 -= 48;
        }
        return ghk[byte0][arg0 * 48 + arg1];
    }

    public int gla(int arg0, int arg1)
    {
        int k = arg0 >> 7;
        int l = arg1 >> 7;
        int i1 = arg0 & 0x7f;
        int j1 = arg1 & 0x7f;
        if(k < 0 || l < 0 || k >= 95 || l >= 95)
            return 0;
        int k1;
        int l1;
        int i2;
        if(i1 <= 128 - j1)
        {
            k1 = gkd(k, l);
            l1 = gkd(k + 1, l) - k1;
            i2 = gkd(k, l + 1) - k1;
        }
        else
        {
            k1 = gkd(k + 1, l + 1);
            l1 = gkd(k, l + 1) - k1;
            i2 = gkd(k + 1, l) - k1;
            i1 = 128 - i1;
            j1 = 128 - j1;
        }
        int j2 = k1 + (l1 * i1) / 128 + (i2 * j1) / 128;
        return j2;
    }

    public void glb()
    {
        for(int k = 0; k < 96; k++)
        {
            for(int l = 0; l < 96; l++)
                if(gjk(k, l, 0) == 250)
                    if(k == 47 && gjk(k + 1, l, 0) != 250 && gjk(k + 1, l, 0) != 2)
                        gje(k, l, 9);
                    else if(l == 47 && gjk(k, l + 1, 0) != 250 && gjk(k, l + 1, 0) != 2)
                        gje(k, l, 9);
                    else
                        gje(k, l, 2);
        }
    }

    public void glc(int arg0, int arg1, int arg2, int arg3)
    {
        if(arg0 < 1 || arg1 < 1 || arg0 + arg2 >= 96 || arg1 + arg3 >= 96)
            return;
        for(int k = arg0; k <= arg0 + arg2; k++)
        {
            for(int l = arg1; l <= arg1 + arg3; l++)
                if((gjl(k, l) & 0x63) != 0 || (gjl(k - 1, l) & 0x59) != 0 || (gjl(k, l - 1) & 0x56) != 0 || (gjl(k - 1, l - 1) & 0x6c) != 0)
                    gkk(k, l, 35);
                else
                    gkk(k, l, 0);
        }
    }

    public boolean gld(int k, int l)
    {
        return gkc(k, l) > 0 && gkc(k - 1, l) > 0 && gkc(k - 1, l - 1) > 0 && gkc(k, l - 1) > 0;
    }

    public void gle(i arg0[])
    {
        for(int k = 0; k < 94; k++)
        {
            for(int l = 0; l < 94; l++)
                if(gkn(k, l) > 48000 && gkn(k, l) < 60000)
                {
                    int i1 = gkn(k, l) - 48001;
                    int j1 = gjh(k, l);
                    int k1;
                    int l1;
                    if(j1 == 0 || j1 == 4)
                    {
                        k1 = Ident.all[i1];
                        l1 = Ident.alm[i1];
                    }
                    else
                    {
                        l1 = Ident.all[i1];
                        k1 = Ident.alm[i1];
                    }
                    addObject(k, l, i1);
                    i i2 = arg0[Ident.alk[i1]].cnk(false, true, false, false);
                    int j2 = ((k + k + k1) * 128) / 2;
                    int l2 = ((l + l + l1) * 128) / 2;
                    i2.cmk(j2, -gla(j2, l2), l2);
                    i2.cmj(0, gjh(k, l) * 32, 0);
                    i2.cmf(48, 48, -50, -10, -50);
                    if(k1 > 1 || l1 > 1)
                    {
                        for(int j3 = k; j3 < k + k1; j3++)
                        {
                            for(int k3 = l; k3 < l + l1; k3++)
                                if((j3 > k || k3 > l) && gkn(j3, k3) - 48001 == i1)
                                {
                                    int k2 = j3;
                                    int i3 = k3;
                                    byte byte0 = 0;
                                    if(k2 >= 48 && i3 < 48)
                                    {
                                        byte0 = 1;
                                        k2 -= 48;
                                    }
                                    else if(k2 < 48 && i3 >= 48)
                                    {
                                        byte0 = 2;
                                        i3 -= 48;
                                    }
                                    else if(k2 >= 48 && i3 >= 48)
                                    {
                                        byte0 = 3;
                                        k2 -= 48;
                                        i3 -= 48;
                                    }
                                    ghk[byte0][k2 * 48 + i3] = 0;
                                }
                        }
                    }
                }
        }
    }

    public int glf(int arg0, int arg1)
    {
        if(arg0 < 0 || arg0 >= 96 || arg1 < 0 || arg1 >= 96)
            return 0;
        byte byte0 = 0;
        if(arg0 >= 48 && arg1 < 48)
        {
            byte0 = 1;
            arg0 -= 48;
        }
        else if(arg0 < 48 && arg1 >= 48)
        {
            byte0 = 2;
            arg1 -= 48;
        }
        else if(arg0 >= 48 && arg1 >= 48)
        {
            byte0 = 3;
            arg0 -= 48;
            arg1 -= 48;
        }
        return ghg[byte0][arg0 * 48 + arg1] & 0xff;
    }

    public int glg(int k, int l, int i1)
    {
        int j1 = gjk(k, l, i1);
        if(j1 == 0)
            return -1;
        int k1 = Ident.ahe[j1 - 1];
        return k1 != 2 ? 0 : 1;
    }

    public Map()
    {
        ghb = new int[96][96];
        ghc = new int[256];
        ghf = false;
        ghg = new byte[4][2304];
        ghh = new int[96][96];
        ghi = true;
        ghj = new int[18432];
        ghk = new int[4][2304];
        ghl = new byte[4][2304];
        ghm = new i[4][64];
        ghn = new byte[4][2304];
        gia = new byte[4][2304];
        gid = new byte[4][2304];
        gie = false;
        gif = new byte[4][2304];
        gig = new int[96][96];
        gih = new i[4][64];
        gik = new byte[4][2304];
        gim = new i[64];
        gjc = new int[18432];
        for(int k = 0; k < 64; k++)
            ghc[k] = Convert.process(255 - k * 4, 255 - (int)((double)k * 1.75D), 255 - k * 4);
        for(int l = 0; l < 64; l++)
            ghc[l + 64] = Convert.process(l * 3, 144, 0);
        for(int i1 = 0; i1 < 64; i1++)
            ghc[i1 + 128] = Convert.process(192 - (int)((double)i1 * 1.5D), 144 - (int)((double)i1 * 1.5D), 0);
        for(int j1 = 0; j1 < 64; j1++)
            ghc[j1 + 192] = Convert.process(96 - (int)((double)j1 * 1.5D), 48 + (int)((double)j1 * 1.5D), 0);
    }

    public void glh(int k, int l, int i1, int j1, int k1)
    {
        int l1 = Ident.akf[k];
        if(gig[l][i1] < 0x13880)
            gig[l][i1] += 0x13880 + l1;
        if(gig[j1][k1] < 0x13880)
            gig[j1][k1] += 0x13880 + l1;
    }

    public void gli(int k, int l, int i1)
    {
        ghb[k][l] |= i1;
    }

    final int ggn = 96;
    final int gha = 96;
    int ghb[][];
    int ghc[];
    boolean ghf;
    byte ghg[][];
    int ghh[][];
    boolean ghi;
    int ghj[];
    int ghk[][];
    byte ghl[][];
    i ghm[][];
    byte ghn[][];
    byte gia[][];
    byte gid[][];
    boolean gie;
    byte gif[][];
    int gig[][];
    i gih[][];
    public static byte[] freeLand;
    public static byte[] freeMaps;
    public static byte[] memberLand;
    public static byte[] memberMaps;
    byte gik[][];
    i gim[];
    i gin;
    final int gja = 0xbc614e;
    final int gjb = 128;
    int gjc[];
}
