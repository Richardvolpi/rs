public class Methods extends Functions {

    public int lockedMode = 1;
    public final int[] BANKERS = {95,224,268,485,540,617};
    public final int[] BONES = {20,413,604,814};
    public final String[] SPELLS = {"Wind strike", "Confuse", "Water strike", "Enchant lvl-1 amulet", "Earth strike", "Weaken", "Fire strike", "Bones to bananas", "Wind bolt", "Curse", "Low level alchemy", "Water bolt", "Varrock teleport", "Enchant lvl-2 amulet", "Earth bolt", "Lumbridge teleport", "Telekinetic grab", "Fire bolt", "Falador teleport", "Crumble undead", "Wind blast", "Superheat item", "Camelot teleport", "Water blast", "Enchant lvl-3 amulet", "Iban blast", "Ardougne teleport", "Earth blast", "High level alchemy", "Charge Water Orb", "Enchant lvl-4 amulet", "Watchtower teleport", "Fire blast", "Claws of Guthix", "Saradomin strike", "Flames of Zamorak", "Charge earth Orb", "Wind wave", "Charge Fire Orb", "Water wave", "Charge air Orb", "Vulnerability", "Enchant lvl-5 amulet", "Earth wave", "Enfeeble", "Fire wave", "Stun", "Charge"};

    public void initVars() {
    }

    public void runScript() {
    }

    public void OnChatMessage(String sender, String message) {
    }

    public void OnPrivateMessage(String sender, String message) {
    }

    public void OnServerMessage(String message) {
    }

}