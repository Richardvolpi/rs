class o
{
    o()
    {
        afk = new int[256];
        afm = new int[257];
        afn = new int[257];
        agc = new boolean[256];
        agd = new boolean[16];
        age = new byte[256];
        agf = new byte[4096];
        agg = new int[16];
        agh = new byte[18002];
        agi = new byte[18002];
        agj = new byte[6][258];
        agk = new int[6][258];
        agl = new int[6][258];
        agm = new int[6][258];
        agn = new int[6];
    }

    final int adj = 4096;
    final int adk = 16;
    final int adl = 258;
    final int adm = 23;
    final int adn = 1;
    final int aea = 6;
    final int aeb = 50;
    final int aec = 4;
    final int aed = 18002;
    byte aee[];
    int aef;
    int aeg;
    int aeh;
    int aei;
    byte aej[];
    int aek;
    int ael;
    int aem;
    int aen;
    byte afa;
    int afb;
    boolean afc;
    int afd;
    int afe;
    int aff;
    int afg;
    int afh;
    int afi;
    int afj;
    int afk[];
    int afl;
    int afm[];
    int afn[];
    public static int aga[];
    int agb;
    boolean agc[];
    boolean agd[];
    byte age[];
    byte agf[];
    int agg[];
    byte agh[];
    byte agi[];
    byte agj[][];
    int agk[][];
    int agl[][];
    int agm[][];
    int agn[];
    int aha;
}