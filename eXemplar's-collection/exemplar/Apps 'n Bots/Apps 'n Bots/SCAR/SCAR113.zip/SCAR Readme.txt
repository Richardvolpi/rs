SCAR Homepage: http://kaitnieks.com/scar/
For help visit http://www.rscheatnet.com/Forums/ 
and click on SCAR forum. DON'T ask for scripts, search
for them using "search" link. Most of the forum users don't like
newcomers, deal it, but if you're nice to them, they're nice to you.

(c) 2004, Kaitnieks (Aivars Irmejs), aivars@serveris.lv
