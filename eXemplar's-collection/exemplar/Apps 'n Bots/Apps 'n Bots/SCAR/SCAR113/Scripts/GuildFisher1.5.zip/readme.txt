README.TXT
-----------
Ok so I noticed how shitty my readme was. I attempted to fix that for this release of the guildfisher. Lots of new things done this version. Many errors/flaws were fixed (of course). As you may know I had surgery this weekend... that means DONATE to my "KEEP THE GUILD-FISHER-MAKER aLIVE!" program, your donations will be greatly appreciated and you will get your name in this readme... yay. Lol. Some of you had a hard time installing this script, dunno why... maybe your retarted... so I added an install section.

FILES
------
BoxBreaker.Txt
Readme.Txt
GuildFisher.Scar
Par.Txt
OSI.Txt

INSTALL
--------
1. Take the zip that you got this file from and open it up.
2. Extract it into a new folder, let's call it "guildfisher".
3. Open up your version of scar and go to file->open-> and find the folder we just made... Click guildfisher.scar.
4. Your installed.

SETUP
------
>Enter your username
>Enter your password
>Enter the type of fish you'd like to get, you have the choices 'swordfish', 'shark', 'lobster', or 'bignet'.
>Enter the skill you'd like to use on your lamp... I'm not gonna tell you what the choices are, look it up in par.txt
>MinTimePerSpot is how many seconds you would like to spend at a fishing spot MINIMUM.
>RanTimePerSpot is how many seconds, randomly calculated with a max of what you put, it will add onto MinTimePerSpot.
>Now enter how long youd like to wait if you find a mod.

> Make sure you have at least 20 of whatever fishing utensil (lobster pots, harpoons) in the first slot of your bank.
> your runescape window is on VBRIGHT