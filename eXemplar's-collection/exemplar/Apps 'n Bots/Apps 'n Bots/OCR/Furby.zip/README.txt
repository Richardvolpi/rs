FFFFFFFF  U   U  RRRR  BBBB   Y   Y
F     	  U   U  R  R  B   B   Y Y
FFFFF     U   U  RRRR  BBBB    Y Y
F         U   U  RR    B   B    Y
F         U   U  R R   B   B    Y
F         UUUUU  R  R  BBBB     Y
------------------------------------
FOCR - Furby Optical character Recognition

SETUP
----------
To setup the program, follow these steps:
   (1) Open (Double Click) Furby.exe
   (2) Make sure that the the path leads to the folder where your bot
      stores HC.bmp.
   (3) Once that is set, double click on [AUTH]
   (4) Put in the username and password for FOCR
   (5) Click OK.
      NOTE: There will be no confirmation.
USING
----------
Follow these steps to use FOCR:
   (1) Make sure the "Enable" Box is checked, and furby's eyes are closed
   (2) Using the bot of your choice, open the sleep screen.
   (3) The bot should automatically detect when HC.bmp is updated, and show
      you the sleep image on the FOCR screen. Within a few seconds,
      slword.txt will be updated with the sleepword, and the bot will
      sleep.

Obtaining an Auth & COntact Information
----------

If you need help with this bot, or wish to buy an authorization, simple connect
to the following IRC Channel:

Server: irc.sbotirc.com
Port: 6667
Channel: #FOCR

Authorizations cost 5mill on RSC or RS2, or $50 through paypal.

Disclaimer
----------
If you are affiliated with any government group, Jagex Ltd, or formerly worked
for either you may not run this program, by running this program, you agree to
these conditions. Also you cannot access any files hosted on the FOCR server,
nor may you threaten to file law suits of any kind towords its users,this
programs's provider, or it's owner. If you pursue such activities then you're
not agreeing to these terms, and you are violating code 431.322.12 of the
Internet Privacy Act signed by Bill Clinton in 1995.

We are not responsible for any actions taken against the users of this program,
and by running this program, you understand the risk of which includes, but
is not limited to, having your character banned.

Use this program at your own risk, it's provided AS IS and with all faults, you
and only you will be responsible if it does any damage to your computer, RS
account, internet connection, hardware, furniture or global climate. Even if
this program contains hostile viruses, trojans or backdoors, I do not take any
responsibility. This program is in a direct violation with RS rules (point 5
and 6) so use of it is totally illegal. It's however legal to keep it on your
computer. You are not allowed to disassemble, modify, hex view or decompile
ANY of FOCR files or use them in other projects without permission. You
are not allowed to sell this program, or give it away to anyone. You are not
allowed to use this project if you don't know what it does and what it is
for. You are not allowed to use or even launch it if you are against bots or
work in a game company. You are not allowed to use it if you don't have the
authorization code. You are not allowed to let anyone else know your code. If
we notice that 2 or more people will use the same authorization code, you lose
it. You are allowed to contact me by email but not expect me to answer you or
even read your suggestions or bug reports. I will however try to do it as often
as I can. If you start worshiping me, or the program, you are not allowed to sacrifice live
people or animals, especially if they are of the virginic essence..