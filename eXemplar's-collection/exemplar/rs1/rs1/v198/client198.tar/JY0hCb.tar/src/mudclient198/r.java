/*
 * Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
 * Jad home page: http://www.geocities.com/kpdus/jad.html
 *
 * Deobfuscatorzd by saevion
 * http://www.rscheatnet.com
 *
 */
  
package mudclient198;

import java.io.IOException;

public class r
{

    public void hbl(int ai[])
    {
        hbb = new p(ai);
        hbc = new p(ai);
    }

    public void baj()
    {
    }

    public int hbm()
        throws IOException
    {
        return bak();
    }

    public void hbn(int i)
    {
        if(gnm > (hbf * 4) / 5)
            try
            {
                hch(0);
            }
            catch(IOException ioexception)
            {
                hbi = true;
                hbj = ioexception.getMessage();
            }
        if(hab == null)
            hab = new byte[hbf];
        hab[gnm + 2] = (byte)i;
        hab[gnm + 3] = 0;
        gnn = gnm + 3;
        haa = 8;
    }

    public void hca(int i)
    {
        hab[gnn++] = (byte)(i >> 24);
        hab[gnn++] = (byte)(i >> 16);
        hab[gnn++] = (byte)(i >> 8);
        hab[gnn++] = (byte)i;
    }

    public long hcb()
        throws IOException
    {
        long l = hcf();
        long l1 = hcf();
        long l2 = hcf();
        long l3 = hcf();
        return (l << 48) + (l1 << 32) + (l2 << 16) + l3;
    }

    public int hcc(byte arg0[])
    {
        try
        {
            gnk++;
            if(gnl > 0 && gnk > gnl)
            {
                hbi = true;
                hbj = "time-out";
                gnl += gnl;
                return 0;
            }
            if(gnj == 0 && bal() >= 2)
            {
                gnj = bak();
                if(gnj >= 160)
                    gnj = (gnj - 160) * 256 + bak();
            }
            if(gnj > 0 && bal() >= gnj)
            {
                if(gnj >= 160)
                {
                    hda(gnj, arg0);
                } else
                {
                    arg0[gnj - 1] = (byte)bak();
                    if(gnj > 1)
                        hda(gnj - 1, arg0);
                }
                int i = gnj;
                gnj = 0;
                gnk = 0;
                return i;
            }
        }
        catch(IOException ioexception)
        {
            hbi = true;
            hbj = ioexception.getMessage();
        }
        return 0;
    }

    public boolean hcd()
    {
        return gnm > 0;
    }

    public void hce(byte arg0[], int arg1, int arg2)
    {
        for(int i = 0; i < arg2; i++)
            hab[gnn++] = arg0[arg1 + i];

    }

    public int bal()
        throws IOException
    {
        return 0;
    }

    public int bak()
        throws IOException
    {
        return 0;
    }

    public int hcf()
        throws IOException
    {
        int i = hbm();
        int j = hbm();
        return i * 256 + j;
    }

    public int hcg(int i)
    {
        return i - hbb.daf() & 0xff;
    }

    public void hch(int i)
        throws IOException
    {
        if(hbi)
        {
            gnm = 0;
            gnn = 3;
            hbi = false;
            throw new IOException(hbj);
        }
        hbg++;
        if(hbg < i)
            return;
        if(gnm > 0)
        {
            hbg = 0;
            ban(hab, 0, gnm);
        }
        gnm = 0;
        gnn = 3;
    }

    public void hci(long l)
    {
        hca((int)(l >> 32));
        hca((int)(l & -1L));
    }

    public void hcj(int i)
    {
        hab[gnn++] = (byte)(i >> 8);
        hab[gnn++] = (byte)i;
    }

    public void hck()
        throws IOException
    {
        hcl();
        hch(0);
    }

    public void ban(byte abyte0[], int i, int j)
        throws IOException
    {
    }

    public void hcl()
    {
        if(hbc != null)
        {
            int i = hab[gnm + 2] & 0xff;
            hab[gnm + 2] = (byte)(i + hbc.daf());
        }
        if(haa != 8)
            gnn++;
        int j = gnn - gnm - 2;
        if(j >= 160)
        {
            hab[gnm] = (byte)(160 + j / 256);
            hab[gnm + 1] = (byte)(j & 0xff);
        } else
        {
            hab[gnm] = (byte)j;
            gnn--;
            hab[gnm + 1] = hab[gnn];
        }
        if(hbf <= 10000)
        {
            int k = hab[gnm + 2] & 0xff;
            hbe[k]++;
            hbh[k] += gnn - gnm;
        }
        gnm = gnn;
    }

    public void hcm(String s)
    {
        s.getBytes(0, s.length(), hab, gnn);
        gnn += s.length();
    }

    public void hcn(int i)
    {
        hab[gnn++] = (byte)i;
    }

    public void hda(int i, byte abyte0[])
        throws IOException
    {
        bam(i, 0, abyte0);
    }

    public void bam(int i, int j, byte abyte0[])
        throws IOException
    {
    }

    public r()
    {
        gnn = 3;
        haa = 8;
        hbf = 5000;
        hbi = false;
        hbj = "";
    }

    protected int gnj;
    public int gnk;
    public int gnl;
    public int gnm;
    private int gnn;
    private int haa;
    public byte hab[];
    private static int hac[] = {
        0, 1, 3, 7, 15, 31, 63, 127, 255, 511, 
        1023, 2047, 4095, 8191, 16383, 32767, 65535, 0x1ffff, 0x3ffff, 0x7ffff, 
        0xfffff, 0x1fffff, 0x3fffff, 0x7fffff, 0xffffff, 0x1ffffff, 0x3ffffff, 0x7ffffff, 0xfffffff, 0x1fffffff, 
        0x3fffffff, 0x7fffffff, -1
    };
    final int had = 61;
    final int hae = 59;
    final int haf = 42;
    final int hag = 43;
    final int hah = 44;
    final int hai = 45;
    final int haj = 46;
    final int hak = 47;
    final int hal = 92;
    final int ham = 32;
    final int han = 124;
    final int hba = 34;
    public p hbb;
    public p hbc;
    static char hbd[];
    public static int hbe[] = new int[256];
    protected int hbf;
    protected int hbg;
    public static int hbh[] = new int[256];
    protected boolean hbi;
    protected String hbj;
    public static int hbk;

    static 
    {
        hbd = new char[256];
        for(int i = 0; i < 256; i++)
            hbd[i] = (char)i;

        hbd[61] = '=';
        hbd[59] = ';';
        hbd[42] = '*';
        hbd[43] = '+';
        hbd[44] = ',';
        hbd[45] = '-';
        hbd[46] = '.';
        hbd[47] = '/';
        hbd[92] = '\\';
        hbd[124] = '|';
        hbd[33] = '!';
        hbd[34] = '"';
    }
}
