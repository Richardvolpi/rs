/*
 * Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
 * Jad home page: http://www.geocities.com/kpdus/jad.html
 *
 * Deobfuscatorzd by saevion
 * http://www.rscheatnet.com
 *
 */
  
package mudclient198;

public class l
{

    public l()
    {
        bld = false;
        blf = -1;
    }

    protected int bkd;
    protected int bke;
    protected int bkf;
    protected int bkg;
    protected int bkh;
    protected int bki;
    protected i bkj;
    protected int bkk;
    protected int bkl;
    protected int bkm;
    protected int bkn;
    protected int bla;
    protected int blb;
    protected int blc;
    protected boolean bld;
    protected int ble;
    protected int blf;
}
