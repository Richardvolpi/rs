/*
 * Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
 * Jad home page: http://www.geocities.com/kpdus/jad.html
 *
 * Deobfuscatorzd by saevion
 * http://www.rscheatnet.com
 *
 */
  
package mudclient198;

public class e
{

    public static int anj(String arg0)
    {
        if(arg0.equalsIgnoreCase("na"))
            return 0;
        for(int i = 0; i < aii; i++)
            if(ame[i].equalsIgnoreCase(arg0))
                return i;

        ame[aii++] = arg0;
        return aii - 1;
    }

    public static int ank()
    {
        int i = anf[anh] & 0xff;
        anh++;
        return i;
    }

    public static int anl()
    {
        int i = t.fmi(anf, anh);
        anh += 2;
        return i;
    }

    public static int anm()
    {
        int i = t.fmj(anf, anh);
        anh += 4;
        if(i > 0x5f5e0ff)
            i = 0x5f5e0ff - i;
        return i;
    }

    public static String ann()
    {
        String s;
        for(s = ""; ane[ang] != 0; s = s + (char)ane[ang++]);
        ang++;
        return s;
    }

    public static void baa(byte arg0[], boolean arg1)
    {
        ane = t.fng("string.dat", 0, arg0);
        ang = 0;
        anf = t.fng("integer.dat", 0, arg0);
        anh = 0;
        aij = anl();
        alb = new String[aij];
        alc = new String[aij];
        ald = new String[aij];
        ahb = new int[aij];
        ahc = new int[aij];
        ahd = new int[aij];
        ahe = new int[aij];
        ahf = new int[aij];
        ahg = new int[aij];
        ahh = new int[aij];
        ahi = new int[aij];
        for(int i = 0; i < aij; i++)
            alb[i] = ann();

        for(int j = 0; j < aij; j++)
            alc[j] = ann();

        for(int k = 0; k < aij; k++)
            ald[k] = ann();

        for(int l = 0; l < aij; l++)
        {
            ahb[l] = anl();
            if(ahb[l] + 1 > aik)
                aik = ahb[l] + 1;
        }

        for(int i1 = 0; i1 < aij; i1++)
            ahc[i1] = anm();

        for(int j1 = 0; j1 < aij; j1++)
            ahd[j1] = ank();

        for(int k1 = 0; k1 < aij; k1++)
            ahe[k1] = ank();

        for(int l1 = 0; l1 < aij; l1++)
            ahf[l1] = anl();

        for(int i2 = 0; i2 < aij; i2++)
            ahg[i2] = anm();

        for(int j2 = 0; j2 < aij; j2++)
            ahh[j2] = ank();

        for(int k2 = 0; k2 < aij; k2++)
            ahi[k2] = ank();

        for(int l2 = 0; l2 < aij; l2++)
            if(!arg1 && ahi[l2] == 1)
            {
                alb[l2] = "Members object";
                alc[l2] = "You need to be a member to use this object";
                ahc[l2] = 0;
                ald[l2] = "";
                ahe[0] = 0;
                ahf[l2] = 0;
                ahh[l2] = 1;
            }

        ama = anl();
        amf = new String[ama];
        amg = new String[ama];
        amh = new String[ama];
        ale = new int[ama];
        alf = new int[ama];
        alg = new int[ama];
        alh = new int[ama];
        ali = new int[ama];
        ajk = new int[ama][12];
        ami = new int[ama];
        amj = new int[ama];
        amk = new int[ama];
        aml = new int[ama];
        aki = new int[ama];
        akj = new int[ama];
        akl = new int[ama];
        akm = new int[ama];
        akn = new int[ama];
        for(int i3 = 0; i3 < ama; i3++)
            amf[i3] = ann();

        for(int j3 = 0; j3 < ama; j3++)
            amg[j3] = ann();

        for(int k3 = 0; k3 < ama; k3++)
            ale[k3] = ank();

        for(int l3 = 0; l3 < ama; l3++)
            alf[l3] = ank();

        for(int i4 = 0; i4 < ama; i4++)
            alg[i4] = ank();

        for(int j4 = 0; j4 < ama; j4++)
            alh[j4] = ank();

        for(int k4 = 0; k4 < ama; k4++)
            ali[k4] = ank();

        for(int l4 = 0; l4 < ama; l4++)
        {
            for(int i5 = 0; i5 < 12; i5++)
            {
                ajk[l4][i5] = ank();
                if(ajk[l4][i5] == 255)
                    ajk[l4][i5] = -1;
            }

        }

        for(int j5 = 0; j5 < ama; j5++)
            ami[j5] = anm();

        for(int k5 = 0; k5 < ama; k5++)
            amj[k5] = anm();

        for(int l5 = 0; l5 < ama; l5++)
            amk[l5] = anm();

        for(int i6 = 0; i6 < ama; i6++)
            aml[i6] = anm();

        for(int j6 = 0; j6 < ama; j6++)
            aki[j6] = anl();

        for(int k6 = 0; k6 < ama; k6++)
            akj[k6] = anl();

        for(int l6 = 0; l6 < ama; l6++)
            akl[l6] = ank();

        for(int i7 = 0; i7 < ama; i7++)
            akm[i7] = ank();

        for(int j7 = 0; j7 < ama; j7++)
            akn[j7] = ank();

        for(int k7 = 0; k7 < ama; k7++)
            amh[k7] = ann();

        ahj = anl();
        aib = new String[ahj];
        aic = new String[ahj];
        for(int l7 = 0; l7 < ahj; l7++)
            aib[l7] = ann();

        for(int i8 = 0; i8 < ahj; i8++)
            aic[i8] = ann();

        amb = anl();
        ail = new String[amb];
        ajd = new int[amb];
        aje = new int[amb];
        ajf = new int[amb];
        ajg = new int[amb];
        ajh = new int[amb];
        for(int j8 = 0; j8 < amb; j8++)
            ail[j8] = ann();

        for(int k8 = 0; k8 < amb; k8++)
            ajd[k8] = anm();

        for(int l8 = 0; l8 < amb; l8++)
            aje[l8] = ank();

        for(int i9 = 0; i9 < amb; i9++)
            ajf[i9] = ank();

        for(int j9 = 0; j9 < amb; j9++)
            ajg[j9] = ank();

        for(int k9 = 0; k9 < amb; k9++)
            ajh[k9] = ank();

        akk = anl();
        ajl = new String[akk];
        ajm = new String[akk];
        ajn = new String[akk];
        aka = new String[akk];
        ahk = new int[akk];
        ahl = new int[akk];
        ahm = new int[akk];
        ahn = new int[akk];
        aia = new int[akk];
        for(int l9 = 0; l9 < akk; l9++)
            ajl[l9] = ann();

        for(int i10 = 0; i10 < akk; i10++)
            ajm[i10] = ann();

        for(int j10 = 0; j10 < akk; j10++)
            ajn[j10] = ann();

        for(int k10 = 0; k10 < akk; k10++)
            aka[k10] = ann();

        for(int l10 = 0; l10 < akk; l10++)
            ahk[l10] = anj(ann());

        for(int i11 = 0; i11 < akk; i11++)
            ahl[i11] = ank();

        for(int j11 = 0; j11 < akk; j11++)
            ahm[j11] = ank();

        for(int k11 = 0; k11 < akk; k11++)
            ahn[k11] = ank();

        for(int l11 = 0; l11 < akk; l11++)
            aia[l11] = ank();

        and = anl();
        aie = new String[and];
        aif = new String[and];
        aig = new String[and];
        aih = new String[and];
        aim = new int[and];
        ain = new int[and];
        aja = new int[and];
        ajb = new int[and];
        ajc = new int[and];
        for(int i12 = 0; i12 < and; i12++)
            aie[i12] = ann();

        for(int j12 = 0; j12 < and; j12++)
            aif[j12] = ann();

        for(int k12 = 0; k12 < and; k12++)
            aig[k12] = ann();

        for(int l12 = 0; l12 < and; l12++)
            aih[l12] = ann();

        for(int i13 = 0; i13 < and; i13++)
            aim[i13] = anl();

        for(int j13 = 0; j13 < and; j13++)
            ain[j13] = anm();

        for(int k13 = 0; k13 < and; k13++)
            aja[k13] = anm();

        for(int l13 = 0; l13 < and; l13++)
            ajb[l13] = ank();

        for(int i14 = 0; i14 < and; i14++)
            ajc[i14] = ank();

        aid = anl();
        amc = new int[aid];
        amd = new int[aid];
        for(int j14 = 0; j14 < aid; j14++)
            amc[j14] = ank();

        for(int k14 = 0; k14 < aid; k14++)
            amd[k14] = ank();

        aln = anl();
        amm = new int[aln];
        amn = new int[aln];
        ana = new int[aln];
        for(int l14 = 0; l14 < aln; l14++)
            amm[l14] = anm();

        for(int i15 = 0; i15 < aln; i15++)
            amn[i15] = ank();

        for(int j15 = 0; j15 < aln; j15++)
            ana[j15] = ank();

        ala = anl();
        alm = anl();
        alk = new String[alm];
        all = new String[alm];
        akc = new int[alm];
        akd = new int[alm];
        ake = new int[alm];
        akf = new int[alm][];
        akg = new int[alm][];
        for(int k15 = 0; k15 < alm; k15++)
            alk[k15] = ann();

        for(int l15 = 0; l15 < alm; l15++)
            all[l15] = ann();

        for(int i16 = 0; i16 < alm; i16++)
            akc[i16] = ank();

        for(int j16 = 0; j16 < alm; j16++)
            akd[j16] = ank();

        for(int k16 = 0; k16 < alm; k16++)
            ake[k16] = ank();

        for(int l16 = 0; l16 < alm; l16++)
        {
            int i17 = ank();
            akf[l16] = new int[i17];
            for(int k17 = 0; k17 < i17; k17++)
                akf[l16][k17] = anl();

        }

        for(int j17 = 0; j17 < alm; j17++)
        {
            int l17 = ank();
            akg[j17] = new int[l17];
            for(int j18 = 0; j18 < l17; j18++)
                akg[j17][j18] = ank();

        }

        akb = anl();
        anb = new String[akb];
        anc = new String[akb];
        aji = new int[akb];
        ajj = new int[akb];
        for(int i18 = 0; i18 < akb; i18++)
            anb[i18] = ann();

        for(int k18 = 0; k18 < akb; k18++)
            anc[k18] = ann();

        for(int l18 = 0; l18 < akb; l18++)
            aji[l18] = ank();

        for(int i19 = 0; i19 < akb; i19++)
            ajj[i19] = ank();

        ane = null;
        anf = null;
    }

    public static int ahb[];
    public static int ahc[];
    public static int ahd[];
    public static int ahe[];
    public static int ahf[];
    public static int ahg[];
    public static int ahh[];
    public static int ahi[];
    public static int ahj;
    public static int ahk[];
    public static int ahl[];
    public static int ahm[];
    public static int ahn[];
    public static int aia[];
    public static String aib[];
    public static String aic[];
    public static int aid;
    public static String aie[];
    public static String aif[];
    public static String aig[];
    public static String aih[];
    public static int aii;
    public static int aij;
    public static int aik;
    public static String ail[];
    public static int aim[];
    public static int ain[];
    public static int aja[];
    public static int ajb[];
    public static int ajc[];
    public static int ajd[];
    public static int aje[];
    public static int ajf[];
    public static int ajg[];
    public static int ajh[];
    public static int aji[];
    public static int ajj[];
    public static int ajk[][];
    public static String ajl[];
    public static String ajm[];
    public static String ajn[];
    public static String aka[];
    public static int akb;
    public static int akc[];
    public static int akd[];
    public static int ake[];
    public static int akf[][];
    public static int akg[][];
    public static String akh[] = new String[5000];
    public static int aki[];
    public static int akj[];
    public static int akk;
    public static int akl[];
    public static int akm[];
    public static int akn[];
    public static int ala;
    public static String alb[];
    public static String alc[];
    public static String ald[];
    public static int ale[];
    public static int alf[];
    public static int alg[];
    public static int alh[];
    public static int ali[];
    public static String alj[] = new String[5000];
    public static String alk[];
    public static String all[];
    public static int alm;
    public static int aln;
    public static int ama;
    public static int amb;
    public static int amc[];
    public static int amd[];
    public static String ame[] = new String[5000];
    public static String amf[];
    public static String amg[];
    public static String amh[];
    public static int ami[];
    public static int amj[];
    public static int amk[];
    public static int aml[];
    public static int amm[];
    public static int amn[];
    public static int ana[];
    public static String anb[];
    public static String anc[];
    public static int and;
    static byte ane[];
    static byte anf[];
    static int ang;
    static int anh;
    public static int ani;

}
