/*
 * Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
 * Jad home page: http://www.geocities.com/kpdus/jad.html
 *
 * Deobfuscatorzd by saevion
 * http://www.rscheatnet.com
 *
 */
  
package mudclient198;

final class f
{

    f()
    {
        gma = new int[10];
        gmb = new int[10];
        gmc = new int[12];
        gml = -1;
        gng = false;
        gnh = -1;
    }

    public long glc;
    public String gld;
    public int gle;
    public int glf;
    public int glg;
    public int glh;
    public int gli;
    public int glj;
    public int glk;
    public int gll;
    public int glm;
    public int gln;
    public int gma[];
    public int gmb[];
    public int gmc[];
    public String gmd;
    public int gme;
    public int gmf;
    public int gmg;
    public int gmh;
    public int gmi;
    public int gmj;
    public int gmk;
    public int gml;
    public int gmm;
    public int gmn;
    public int gna;
    public int gnb;
    public int gnc;
    public int gnd;
    public int gne;
    public int gnf;
    public boolean gng;
    public int gnh;
    public int gni;
}
