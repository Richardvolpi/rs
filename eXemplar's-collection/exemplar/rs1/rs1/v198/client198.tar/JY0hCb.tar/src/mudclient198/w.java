/*
 * Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
 * Jad home page: http://www.geocities.com/kpdus/jad.html
 *
 * Deobfuscatorzd by saevion
 * http://www.rscheatnet.com
 *
 */
  
package mudclient198;

public class w
{

    public static int cel = 198;
    public static int cem = 198;
    public static int cen = 85;
    public static int cfa = 63;
    public static int cfb = 58;
    public static int cfc = 36;
    public static int cfd = 17;
    public static int cfe = 24;
    public static int cff = 1;
    public static int cfg = 2;

}
