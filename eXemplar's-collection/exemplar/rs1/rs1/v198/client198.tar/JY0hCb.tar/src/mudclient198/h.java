/*
 * Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
 * Jad home page: http://www.geocities.com/kpdus/jad.html
 *
 * Deobfuscatorzd by saevion
 * http://www.rscheatnet.com
 *
 */
  
package mudclient198;

public class h
{

    public h(j j1, int i)
    {
        gbf = -1;
        gcf = true;
        fni = j1;
        fnk = i;
        fnl = new boolean[i];
        fnm = new boolean[i];
        fnn = new boolean[i];
        gaa = new boolean[i];
        gaf = new boolean[i];
        gab = new int[i];
        gac = new int[i];
        gad = new int[i];
        gae = new int[i];
        gag = new int[i];
        gah = new int[i];
        gai = new int[i];
        gaj = new int[i];
        gak = new int[i];
        gal = new int[i];
        gam = new int[i];
        gan = new String[i];
        gba = new String[i][];
        gbh = gcm(114, 114, 176);
        gbi = gcm(14, 14, 62);
        gbj = gcm(200, 208, 232);
        gbk = gcm(96, 129, 184);
        gbl = gcm(53, 95, 115);
        gbm = gcm(117, 142, 171);
        gbn = gcm(98, 122, 158);
        gca = gcm(86, 100, 136);
        gcb = gcm(135, 146, 179);
        gcc = gcm(97, 112, 151);
        gcd = gcm(88, 102, 136);
        gce = gcm(84, 93, 120);
    }

    public int gcm(int i, int k, int l)
    {
        return j.cbh((gci * i) / 114, (gcj * k) / 114, (gck * l) / 176);
    }

    public void gcn(int arg0, int arg1, int arg2, int arg3)
    {
        gbb = arg0;
        gbc = arg1;
        gbe = arg3;
        if(arg2 != 0)
            gbd = arg2;
        if(arg2 == 1)
        {
            for(int i = 0; i < fnj; i++)
            {
                if(fnl[i] && gai[i] == 10 && gbb >= gag[i] && gbc >= gah[i] && gbb <= gag[i] + gaj[i] && gbc <= gah[i] + gak[i])
                    gaa[i] = true;
                if(fnl[i] && gai[i] == 14 && gbb >= gag[i] && gbc >= gah[i] && gbb <= gag[i] + gaj[i] && gbc <= gah[i] + gak[i])
                    gad[i] = 1 - gad[i];
            }

        }
        if(arg3 == 1)
            gbg++;
        else
            gbg = 0;
        if(arg2 == 1 || gbg > 20)
        {
            for(int k = 0; k < fnj; k++)
                if(fnl[k] && gai[k] == 15 && gbb >= gag[k] && gbc >= gah[k] && gbb <= gag[k] + gaj[k] && gbc <= gah[k] + gak[k])
                    gaa[k] = true;

            gbg -= 5;
        }
    }

    public boolean gda(int i)
    {
        if(fnl[i] && gaa[i])
        {
            gaa[i] = false;
            return true;
        } else
        {
            return false;
        }
    }

    public void gdb(int arg0)
    {
        if(arg0 == 0)
            return;
        if(gbf != -1 && gan[gbf] != null && fnl[gbf])
        {
            int i = gan[gbf].length();
            if(arg0 == 8 && i > 0)
                gan[gbf] = gan[gbf].substring(0, i - 1);
            if((arg0 == 10 || arg0 == 13) && i > 0)
                gaa[gbf] = true;
            String s = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!\"\243$%^&*()-_=+[{]};:'@#~,<.>/?\\| ";
            if(i < gal[gbf])
            {
                for(int k = 0; k < 95; k++)
                    if(arg0 == "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!\"\243$%^&*()-_=+[{]};:'@#~,<.>/?\\| ".charAt(k))
                        gan[gbf] += (char)arg0;

            }
            if(arg0 == 9)
            {
                do
                    gbf = (gbf + 1) % fnj;
                while(gai[gbf] != 5 && gai[gbf] != 6);
                return;
            }
        }
    }

    public void gdc()
    {
        for(int i = 0; i < fnj; i++)
            if(fnl[i])
                if(gai[i] == 0)
                    gde(i, gag[i], gah[i], gan[i], gam[i]);
                else
                if(gai[i] == 1)
                    gde(i, gag[i] - fni.cef(gan[i], gam[i]) / 2, gah[i], gan[i], gam[i]);
                else
                if(gai[i] == 2)
                    gdh(gag[i], gah[i], gaj[i], gak[i]);
                else
                if(gai[i] == 3)
                    gdk(gag[i], gah[i], gaj[i]);
                else
                if(gai[i] == 4)
                    gdl(i, gag[i], gah[i], gaj[i], gak[i], gam[i], gba[i], gac[i], gab[i]);
                else
                if(gai[i] == 5 || gai[i] == 6)
                    gdg(i, gag[i], gah[i], gaj[i], gak[i], gan[i], gam[i]);
                else
                if(gai[i] == 7)
                    gdn(i, gag[i], gah[i], gam[i], gba[i]);
                else
                if(gai[i] == 8)
                    gea(i, gag[i], gah[i], gam[i], gba[i]);
                else
                if(gai[i] == 9)
                    geb(i, gag[i], gah[i], gaj[i], gak[i], gam[i], gba[i], gac[i], gab[i]);
                else
                if(gai[i] == 11)
                    gdi(gag[i], gah[i], gaj[i], gak[i]);
                else
                if(gai[i] == 12)
                    gdj(gag[i], gah[i], gam[i]);
                else
                if(gai[i] == 14)
                    gdd(i, gag[i], gah[i], gaj[i], gak[i]);

        gbd = 0;
    }

    protected void gdd(int arg0, int arg1, int arg2, int arg3, int arg4)
    {
        fni.cba(arg1, arg2, arg3, arg4, 0xffffff);
        fni.cbc(arg1, arg2, arg3, gcb);
        fni.cbd(arg1, arg2, arg4, gcb);
        fni.cbc(arg1, (arg2 + arg4) - 1, arg3, gce);
        fni.cbd((arg1 + arg3) - 1, arg2, arg4, gce);
        if(gad[arg0] == 1)
        {
            for(int i = 0; i < arg4; i++)
            {
                fni.cbc(arg1 + i, arg2 + i, 1, 0);
                fni.cbc((arg1 + arg3) - 1 - i, arg2 + i, 1, 0);
            }

        }
    }

    protected void gde(int i, int k, int l, String s, int i1)
    {
        int j1 = l + fni.ced(i1) / 3;
        gdf(i, k, j1, s, i1);
    }

    protected void gdf(int arg0, int arg1, int arg2, String arg3, int arg4)
    {
        int i;
        if(gaf[arg0])
            i = 0xffffff;
        else
            i = 0;
        fni.cdn(arg3, arg1, arg2, arg4, i);
    }

    protected void gdg(int arg0, int arg1, int arg2, int arg3, int arg4, String arg5, int arg6)
    {
        if(fnn[arg0])
        {
            int i = arg5.length();
            arg5 = "";
            for(int l = 0; l < i; l++)
                arg5 = arg5 + "X";

        }
        if(gai[arg0] == 5)
        {
            if(gbd == 1 && gbb >= arg1 && gbc >= arg2 - arg4 / 2 && gbb <= arg1 + arg3 && gbc <= arg2 + arg4 / 2)
                gbf = arg0;
        } else
        if(gai[arg0] == 6)
        {
            if(gbd == 1 && gbb >= arg1 - arg3 / 2 && gbc >= arg2 - arg4 / 2 && gbb <= arg1 + arg3 / 2 && gbc <= arg2 + arg4 / 2)
                gbf = arg0;
            arg1 -= fni.cef(arg5, arg6) / 2;
        }
        if(gbf == arg0)
            arg5 = arg5 + "*";
        int k = arg2 + fni.ced(arg6) / 3;
        gdf(arg0, arg1, k, arg5, arg6);
    }

    public void gdh(int arg0, int arg1, int arg2, int arg3)
    {
        fni.cah(arg0, arg1, arg0 + arg2, arg1 + arg3);
        fni.can(arg0, arg1, arg2, arg3, gce, gcb);
        if(gcg)
        {
            for(int i = arg0 - (arg1 & 0x3f); i < arg0 + arg2; i += 128)
            {
                for(int k = arg1 - (arg1 & 0x1f); k < arg1 + arg3; k += 128)
                    fni.ccd(i, k, 6 + gch, 128);

            }

        }
        fni.cbc(arg0, arg1, arg2, gcb);
        fni.cbc(arg0 + 1, arg1 + 1, arg2 - 2, gcb);
        fni.cbc(arg0 + 2, arg1 + 2, arg2 - 4, gcc);
        fni.cbd(arg0, arg1, arg3, gcb);
        fni.cbd(arg0 + 1, arg1 + 1, arg3 - 2, gcb);
        fni.cbd(arg0 + 2, arg1 + 2, arg3 - 4, gcc);
        fni.cbc(arg0, (arg1 + arg3) - 1, arg2, gce);
        fni.cbc(arg0 + 1, (arg1 + arg3) - 2, arg2 - 2, gce);
        fni.cbc(arg0 + 2, (arg1 + arg3) - 3, arg2 - 4, gcd);
        fni.cbd((arg0 + arg2) - 1, arg1, arg3, gce);
        fni.cbd((arg0 + arg2) - 2, arg1 + 1, arg3 - 2, gce);
        fni.cbd((arg0 + arg2) - 3, arg1 + 2, arg3 - 4, gcd);
        fni.cai();
    }

    public void gdi(int i, int k, int l, int i1)
    {
        fni.cba(i, k, l, i1, 0);
        fni.cbb(i, k, l, i1, gbm);
        fni.cbb(i + 1, k + 1, l - 2, i1 - 2, gbn);
        fni.cbb(i + 2, k + 2, l - 4, i1 - 4, gca);
        fni.ccb(i, k, 2 + gch);
        fni.ccb((i + l) - 7, k, 3 + gch);
        fni.ccb(i, (k + i1) - 7, 4 + gch);
        fni.ccb((i + l) - 7, (k + i1) - 7, 5 + gch);
    }

    protected void gdj(int i, int k, int l)
    {
        fni.ccb(i, k, l);
    }

    protected void gdk(int i, int k, int l)
    {
        fni.cbc(i, k, l, 0);
    }

    protected void gdl(int arg0, int arg1, int arg2, int arg3, int arg4, int arg5, String arg6[], 
            int arg7, int arg8)
    {
        int i = arg4 / fni.ced(arg5);
        if(arg8 > arg7 - i)
            arg8 = arg7 - i;
        if(arg8 < 0)
            arg8 = 0;
        gab[arg0] = arg8;
        if(i < arg7)
        {
            int k = (arg1 + arg3) - 12;
            int i1 = ((arg4 - 27) * i) / arg7;
            if(i1 < 6)
                i1 = 6;
            int k1 = ((arg4 - 27 - i1) * arg8) / (arg7 - i);
            if(gbe == 1 && gbb >= k && gbb <= k + 12)
            {
                if(gbc > arg2 && gbc < arg2 + 12 && arg8 > 0)
                    arg8--;
                if(gbc > (arg2 + arg4) - 12 && gbc < arg2 + arg4 && arg8 < arg7 - i)
                    arg8++;
                gab[arg0] = arg8;
            }
            if(gbe == 1 && (gbb >= k && gbb <= k + 12 || gbb >= k - 12 && gbb <= k + 24 && fnm[arg0]))
            {
                if(gbc > arg2 + 12 && gbc < (arg2 + arg4) - 12)
                {
                    fnm[arg0] = true;
                    int i2 = gbc - arg2 - 12 - i1 / 2;
                    arg8 = (i2 * arg7) / (arg4 - 24);
                    if(arg8 > arg7 - i)
                        arg8 = arg7 - i;
                    if(arg8 < 0)
                        arg8 = 0;
                    gab[arg0] = arg8;
                }
            } else
            {
                fnm[arg0] = false;
            }
            k1 = ((arg4 - 27 - i1) * arg8) / (arg7 - i);
            gdm(arg1, arg2, arg3, arg4, k1, i1);
        }
        int l = arg4 - i * fni.ced(arg5);
        int j1 = arg2 + (fni.ced(arg5) * 5) / 6 + l / 2;
        for(int l1 = arg8; l1 < arg7; l1++)
        {
            gdf(arg0, arg1 + 2, j1, arg6[l1], arg5);
            j1 += fni.ced(arg5) - gcl;
            if(j1 >= arg2 + arg4)
                return;
        }

    }

    protected void gdm(int i, int k, int l, int i1, int j1, int k1)
    {
        int l1 = (i + l) - 12;
        fni.cbb(l1, k, 12, i1, 0);
        fni.ccb(l1 + 1, k + 1, gch);
        fni.ccb(l1 + 1, (k + i1) - 12, 1 + gch);
        fni.cbc(l1, k + 13, 12, 0);
        fni.cbc(l1, (k + i1) - 13, 12, 0);
        fni.can(l1 + 1, k + 14, 11, i1 - 27, gbh, gbi);
        fni.cba(l1 + 3, j1 + k + 14, 7, k1, gbk);
        fni.cbd(l1 + 2, j1 + k + 14, k1, gbj);
        fni.cbd(l1 + 2 + 8, j1 + k + 14, k1, gbl);
    }

    protected void gdn(int arg0, int arg1, int arg2, int arg3, String arg4[])
    {
        int i = 0;
        int k = arg4.length;
        for(int l = 0; l < k; l++)
        {
            i += fni.cef(arg4[l], arg3);
            if(l < k - 1)
                i += fni.cef("  ", arg3);
        }

        int i1 = arg1 - i / 2;
        int j1 = arg2 + fni.ced(arg3) / 3;
        for(int k1 = 0; k1 < k; k1++)
        {
            int l1;
            if(gaf[arg0])
                l1 = 0xffffff;
            else
                l1 = 0;
            if(gbb >= i1 && gbb <= i1 + fni.cef(arg4[k1], arg3) && gbc <= j1 && gbc > j1 - fni.ced(arg3))
            {
                if(gaf[arg0])
                    l1 = 0x808080;
                else
                    l1 = 0xffffff;
                if(gbd == 1)
                {
                    gad[arg0] = k1;
                    gaa[arg0] = true;
                }
            }
            if(gad[arg0] == k1)
                if(gaf[arg0])
                    l1 = 0xff0000;
                else
                    l1 = 0xc00000;
            fni.cdn(arg4[k1], i1, j1, arg3, l1);
            i1 += fni.cef(arg4[k1] + "  ", arg3);
        }

    }

    protected void gea(int arg0, int arg1, int arg2, int arg3, String arg4[])
    {
        int i = arg4.length;
        int k = arg2 - (fni.ced(arg3) * (i - 1)) / 2;
        for(int l = 0; l < i; l++)
        {
            int i1;
            if(gaf[arg0])
                i1 = 0xffffff;
            else
                i1 = 0;
            int j1 = fni.cef(arg4[l], arg3);
            if(gbb >= arg1 - j1 / 2 && gbb <= arg1 + j1 / 2 && gbc - 2 <= k && gbc - 2 > k - fni.ced(arg3))
            {
                if(gaf[arg0])
                    i1 = 0x808080;
                else
                    i1 = 0xffffff;
                if(gbd == 1)
                {
                    gad[arg0] = l;
                    gaa[arg0] = true;
                }
            }
            if(gad[arg0] == l)
                if(gaf[arg0])
                    i1 = 0xff0000;
                else
                    i1 = 0xc00000;
            fni.cdn(arg4[l], arg1 - j1 / 2, k, arg3, i1);
            k += fni.ced(arg3);
        }

    }

    protected void geb(int arg0, int arg1, int arg2, int arg3, int arg4, int arg5, String arg6[], 
            int arg7, int arg8)
    {
        int i = arg4 / fni.ced(arg5);
        if(i < arg7)
        {
            int k = (arg1 + arg3) - 12;
            int i1 = ((arg4 - 27) * i) / arg7;
            if(i1 < 6)
                i1 = 6;
            int k1 = ((arg4 - 27 - i1) * arg8) / (arg7 - i);
            if(gbe == 1 && gbb >= k && gbb <= k + 12)
            {
                if(gbc > arg2 && gbc < arg2 + 12 && arg8 > 0)
                    arg8--;
                if(gbc > (arg2 + arg4) - 12 && gbc < arg2 + arg4 && arg8 < arg7 - i)
                    arg8++;
                gab[arg0] = arg8;
            }
            if(gbe == 1 && (gbb >= k && gbb <= k + 12 || gbb >= k - 12 && gbb <= k + 24 && fnm[arg0]))
            {
                if(gbc > arg2 + 12 && gbc < (arg2 + arg4) - 12)
                {
                    fnm[arg0] = true;
                    int i2 = gbc - arg2 - 12 - i1 / 2;
                    arg8 = (i2 * arg7) / (arg4 - 24);
                    if(arg8 < 0)
                        arg8 = 0;
                    if(arg8 > arg7 - i)
                        arg8 = arg7 - i;
                    gab[arg0] = arg8;
                }
            } else
            {
                fnm[arg0] = false;
            }
            k1 = ((arg4 - 27 - i1) * arg8) / (arg7 - i);
            gdm(arg1, arg2, arg3, arg4, k1, i1);
        } else
        {
            arg8 = 0;
            gab[arg0] = 0;
        }
        gae[arg0] = -1;
        int l = arg4 - i * fni.ced(arg5);
        int j1 = arg2 + (fni.ced(arg5) * 5) / 6 + l / 2;
        for(int l1 = arg8; l1 < arg7; l1++)
        {
            int j2;
            if(gaf[arg0])
                j2 = 0xffffff;
            else
                j2 = 0;
            if(gbb >= arg1 + 2 && gbb <= arg1 + 2 + fni.cef(arg6[l1], arg5) && gbc - 2 <= j1 && gbc - 2 > j1 - fni.ced(arg5))
            {
                if(gaf[arg0])
                    j2 = 0x808080;
                else
                    j2 = 0xffffff;
                gae[arg0] = l1;
                if(gbd == 1)
                {
                    gad[arg0] = l1;
                    gaa[arg0] = true;
                }
            }
            if(gad[arg0] == l1 && gcf)
                j2 = 0xff0000;
            fni.cdn(arg6[l1], arg1 + 2, j1, arg5, j2);
            j1 += fni.ced(arg5);
            if(j1 >= arg2 + arg4)
                return;
        }

    }

    public int gec(int i, int k, String s, int l, boolean flag)
    {
        gai[fnj] = 1;
        fnl[fnj] = true;
        gaa[fnj] = false;
        gam[fnj] = l;
        gaf[fnj] = flag;
        gag[fnj] = i;
        gah[fnj] = k;
        gan[fnj] = s;
        return fnj++;
    }

    public int ged(int i, int k, int l, int i1)
    {
        gai[fnj] = 2;
        fnl[fnj] = true;
        gaa[fnj] = false;
        gag[fnj] = i - l / 2;
        gah[fnj] = k - i1 / 2;
        gaj[fnj] = l;
        gak[fnj] = i1;
        return fnj++;
    }

    public int gee(int i, int k, int l, int i1)
    {
        gai[fnj] = 11;
        fnl[fnj] = true;
        gaa[fnj] = false;
        gag[fnj] = i - l / 2;
        gah[fnj] = k - i1 / 2;
        gaj[fnj] = l;
        gak[fnj] = i1;
        return fnj++;
    }

    public int gef(int i, int k, int l)
    {
        int i1 = fni.bmf[l];
        int j1 = fni.bmg[l];
        gai[fnj] = 12;
        fnl[fnj] = true;
        gaa[fnj] = false;
        gag[fnj] = i - i1 / 2;
        gah[fnj] = k - j1 / 2;
        gaj[fnj] = i1;
        gak[fnj] = j1;
        gam[fnj] = l;
        return fnj++;
    }

    public int geg(int i, int k, int l, int i1, int j1, int k1, boolean flag)
    {
        gai[fnj] = 4;
        fnl[fnj] = true;
        gaa[fnj] = false;
        gag[fnj] = i;
        gah[fnj] = k;
        gaj[fnj] = l;
        gak[fnj] = i1;
        gaf[fnj] = flag;
        gam[fnj] = j1;
        gal[fnj] = k1;
        gac[fnj] = 0;
        gab[fnj] = 0;
        gba[fnj] = new String[k1];
        return fnj++;
    }

    public int geh(int i, int k, int l, int i1, int j1, int k1, boolean flag, 
            boolean flag1)
    {
        gai[fnj] = 5;
        fnl[fnj] = true;
        fnn[fnj] = flag;
        gaa[fnj] = false;
        gam[fnj] = j1;
        gaf[fnj] = flag1;
        gag[fnj] = i;
        gah[fnj] = k;
        gaj[fnj] = l;
        gak[fnj] = i1;
        gal[fnj] = k1;
        gan[fnj] = "";
        return fnj++;
    }

    public int gei(int i, int k, int l, int i1, int j1, int k1, boolean flag, 
            boolean flag1)
    {
        gai[fnj] = 6;
        fnl[fnj] = true;
        fnn[fnj] = flag;
        gaa[fnj] = false;
        gam[fnj] = j1;
        gaf[fnj] = flag1;
        gag[fnj] = i;
        gah[fnj] = k;
        gaj[fnj] = l;
        gak[fnj] = i1;
        gal[fnj] = k1;
        gan[fnj] = "";
        return fnj++;
    }

    public int gej(int i, int k, int l, int i1, int j1, int k1, boolean flag)
    {
        gai[fnj] = 9;
        fnl[fnj] = true;
        gaa[fnj] = false;
        gam[fnj] = j1;
        gaf[fnj] = flag;
        gag[fnj] = i;
        gah[fnj] = k;
        gaj[fnj] = l;
        gak[fnj] = i1;
        gal[fnj] = k1;
        gba[fnj] = new String[k1];
        gac[fnj] = 0;
        gab[fnj] = 0;
        gad[fnj] = -1;
        gae[fnj] = -1;
        return fnj++;
    }

    public int gek(int i, int k, int l, int i1)
    {
        gai[fnj] = 10;
        fnl[fnj] = true;
        gaa[fnj] = false;
        gag[fnj] = i - l / 2;
        gah[fnj] = k - i1 / 2;
        gaj[fnj] = l;
        gak[fnj] = i1;
        return fnj++;
    }

    public void gel(int i)
    {
        gac[i] = 0;
    }

    public void gem(int i)
    {
        gab[i] = 0;
        gae[i] = -1;
    }

    public void gen(int i, int k, String s)
    {
        gba[i][k] = s;
        if(k + 1 > gac[i])
            gac[i] = k + 1;
    }

    public void gfa(int arg0, String arg1, boolean arg2)
    {
        int i = gac[arg0]++;
        if(i >= gal[arg0])
        {
            i--;
            gac[arg0]--;
            for(int k = 0; k < i; k++)
                gba[arg0][k] = gba[arg0][k + 1];

        }
        gba[arg0][i] = arg1;
        if(arg2)
            gab[arg0] = 0xf423f;
    }

    public void gfb(int i, String s)
    {
        gan[i] = s;
    }

    public String gfc(int i)
    {
        if(gan[i] == null)
            return "null";
        else
            return gan[i];
    }

    public void gfd(int i)
    {
        fnl[i] = true;
    }

    public void gfe(int i)
    {
        fnl[i] = false;
    }

    public void gff(int i)
    {
        gbf = i;
    }

    public int gfg(int i)
    {
        int k = gae[i];
        return k;
    }

    protected j fni;
    int fnj;
    int fnk;
    public boolean fnl[];
    public boolean fnm[];
    public boolean fnn[];
    public boolean gaa[];
    public int gab[];
    public int gac[];
    public int gad[];
    public int gae[];
    boolean gaf[];
    int gag[];
    int gah[];
    int gai[];
    int gaj[];
    int gak[];
    int gal[];
    int gam[];
    String gan[];
    String gba[][];
    int gbb;
    int gbc;
    int gbd;
    int gbe;
    int gbf;
    int gbg;
    int gbh;
    int gbi;
    int gbj;
    int gbk;
    int gbl;
    int gbm;
    int gbn;
    int gca;
    int gcb;
    int gcc;
    int gcd;
    int gce;
    public boolean gcf;
    public static boolean gcg = true;
    public static int gch;
    public static int gci = 114;
    public static int gcj = 114;
    public static int gck = 176;
    public static int gcl;

}
