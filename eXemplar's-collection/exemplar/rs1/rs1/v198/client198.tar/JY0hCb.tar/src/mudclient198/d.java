/*
 * Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
 * Jad home page: http://www.geocities.com/kpdus/jad.html
 *
 * Deobfuscatorzd by saevion
 * http://www.rscheatnet.com
 *
 */
  
package mudclient198;

import java.io.InputStream;
import sun.audio.AudioPlayer;

public class d extends InputStream
{

    public d()
    {
        AudioPlayer.player.start(this);
    }

    public void gfk()
    {
        AudioPlayer.player.stop(this);
    }

    public void gfl(byte abyte0[], int i, int j)
    {
        gfh = abyte0;
        gfi = i;
        gfj = i + j;
    }

    public int read(byte arg0[], int arg1, int arg2)
    {
        for(int i = 0; i < arg2; i++)
            if(gfi < gfj)
                arg0[arg1 + i] = gfh[gfi++];
            else
                arg0[arg1 + i] = -1;

        return arg2;
    }

    public int read()
    {
        byte abyte0[] = new byte[1];
        read(abyte0, 0, 1);
        return abyte0[0];
    }

    byte gfh[];
    int gfi;
    int gfj;
}
