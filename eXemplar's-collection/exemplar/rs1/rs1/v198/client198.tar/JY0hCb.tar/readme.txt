
rs1 client198 deobfuscatorzd by saevion for rscn [http://www.rscheatnet.com].

to compile:
	type 'javac <src dir>/*.java' from a command prompt.
	
	make sure that you have the Java SDK installed.
	ignore any compiler warnings about deprecated api's 


to run:
	type 'java <src dir>/mudclient' from a command prompt.
	
	of course the client will not run locally without some modifications
	see the rscheatnet forums for help.


props to:
	the jakarta group for bcel and the regular expression api's [http://jakarta.apache.org/].
	
	JODE for the nice renamer [http://jode.sourceforge.net].
	
	Sean, eP, and everyone else that matters, you know who you are.
	




